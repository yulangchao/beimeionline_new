<?php
require_once(dirname(__FILE__)."/../../../inc/common.inc.php");    
require_once("editmode.htm");
?>


