

var KE_TITLE_value = '<div style="width:140px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TITLE_END\', \'H1\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';"><H1 style="margin:2px;">���� 1</H1></div><div style="width:140px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TITLE_END\', \'H2\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';"><H2 style="margin:2px;">���� 2</H2></div><div style="width:140px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TITLE_END\', \'H3\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';"><H3 style="margin:2px;">���� 3</H3></div><div style="width:140px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TITLE_END\', \'H4\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';"><H4 style="margin:2px;">���� 4</H4></div><div style="width:140px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TITLE_END\', \'H5\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';"><H5 style="margin:2px;">���� 5</H5></div><div style="width:140px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TITLE_END\', \'H6\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';"><H6 style="margin:2px;">���� 6</H6></div>';
var KE_ZOOM_value = '<div style="padding:2px;width:120px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ZOOM_END\', \'250%\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">250%</div><div style="padding:2px;width:120px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ZOOM_END\', \'200%\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">200%</div><div style="padding:2px;width:120px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ZOOM_END\', \'150%\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">150%</div><div style="padding:2px;width:120px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ZOOM_END\', \'120%\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">120%</div><div style="padding:2px;width:120px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ZOOM_END\', \'100%\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">100%</div><div style="padding:2px;width:120px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ZOOM_END\', \'80%\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">80%</div><div style="padding:2px;width:120px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ZOOM_END\', \'50%\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">50%</div>';
var KE_FONTSIZE_value = '<div style="font-size:8pt;padding:2px;width:120px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_FONTSIZE_END\', \'1\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">8pt</div><div style="font-size:10pt;padding:2px;width:120px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_FONTSIZE_END\', \'2\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">10pt</div><div style="font-size:12pt;padding:2px;width:120px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_FONTSIZE_END\', \'3\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">12pt</div><div style="font-size:14pt;padding:2px;width:120px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_FONTSIZE_END\', \'4\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">14pt</div><div style="font-size:18pt;padding:2px;width:120px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_FONTSIZE_END\', \'5\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">18pt</div><div style="font-size:24pt;padding:2px;width:120px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_FONTSIZE_END\', \'6\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">24pt</div><div style="font-size:36pt;padding:2px;width:120px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_FONTSIZE_END\', \'7\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">36pt</div>';
var KE_FONTNAME_value = '<div style="font-family:SimSun;padding:2px;width:160px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_FONTNAME_END\', \'SimSun\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">����</div><div style="font-family:SimHei;padding:2px;width:160px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_FONTNAME_END\', \'SimHei\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">����</div><div style="font-family:FangSong_GB2312;padding:2px;width:160px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_FONTNAME_END\', \'FangSong_GB2312\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">������</div><div style="font-family:KaiTi_GB2312;padding:2px;width:160px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_FONTNAME_END\', \'KaiTi_GB2312\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">����</div><div style="font-family:NSimSun;padding:2px;width:160px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_FONTNAME_END\', \'NSimSun\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">������</div><div style="font-family:Arial;padding:2px;width:160px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_FONTNAME_END\', \'Arial\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">Arial</div><div style="font-family:Arial Black;padding:2px;width:160px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_FONTNAME_END\', \'Arial Black\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">Arial Black</div><div style="font-family:Times New Roman;padding:2px;width:160px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_FONTNAME_END\', \'Times New Roman\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">Times New Roman</div><div style="font-family:Courier New;padding:2px;width:160px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_FONTNAME_END\', \'Courier New\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">Courier New</div><div style="font-family:Tahoma;padding:2px;width:160px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_FONTNAME_END\', \'Tahoma\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">Tahoma</div><div style="font-family:Verdana;padding:2px;width:160px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_FONTNAME_END\', \'Verdana\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">Verdana</div><div style="font-family:GulimChe;padding:2px;width:160px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_FONTNAME_END\', \'GulimChe\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">GulimChe</div><div style="font-family:MS Gothic;padding:2px;width:160px;cursor:pointer;" onclick="javascript:KindExecute(\'KE_FONTNAME_END\', \'MS Gothic\');" onmouseover="javascript:this.style.backgroundColor=\'#CCCCCC\';" onmouseout="javascript:this.style.backgroundColor=\'#EFEFEF\';">MS Gothic</div>';
var KE_TEXTCOLOR_value = '<table cellpadding="0" cellspacing="2" border="0"><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF0000;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FF0000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFF00;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFFF00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FF00;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#00FF00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#00FFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#0000FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#0000FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF00FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FF00FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFFFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F5F5F5;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#F5F5F5\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DCDCDC;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#DCDCDC\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFAFA;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFFAFA\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#D3D3D3;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#D3D3D3\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#C0C0C0;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#C0C0C0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#A9A9A9;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#A9A9A9\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#808080;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#808080\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#696969;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#696969\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#000000;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#000000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#2F4F4F;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#2F4F4F\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#708090;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#708090\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#778899;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#778899\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#4682B4;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#4682B4\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#4169E1;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#4169E1\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#6495ED;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#6495ED\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#B0C4DE;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#B0C4DE\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#7B68EE;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#7B68EE\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#6A5ACD;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#6A5ACD\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#483D8B;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#483D8B\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#191970;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#191970\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#000080;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#000080\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00008B;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#00008B\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#0000CD;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#0000CD\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#1E90FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#1E90FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00BFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#00BFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#87CEFA;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#87CEFA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#87CEEB;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#87CEEB\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#ADD8E6;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#ADD8E6\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#B0E0E6;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#B0E0E6\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F0FFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#F0FFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#E0FFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#E0FFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#AFEEEE;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#AFEEEE\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00CED1;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#00CED1\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#5F9EA0;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#5F9EA0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#48D1CC;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#48D1CC\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#00FFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#40E0D0;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#40E0D0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#20B2AA;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#20B2AA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#008B8B;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#008B8B\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#008080;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#008080\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#7FFFD4;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#7FFFD4\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#66CDAA;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#66CDAA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#8FBC8F;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#8FBC8F\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#3CB371;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#3CB371\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#2E8B57;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#2E8B57\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#006400;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#006400\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#008000;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#008000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#228B22;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#228B22\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#32CD32;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#32CD32\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FF00;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#00FF00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#7FFF00;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#7FFF00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#7CFC00;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#7CFC00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#ADFF2F;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#ADFF2F\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#98FB98;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#98FB98\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#90EE90;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#90EE90\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FF7F;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#00FF7F\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FA9A;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#00FA9A\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#556B2F;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#556B2F\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#6B8E23;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#6B8E23\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#808000;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#808000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#BDB76B;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#BDB76B\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#B8860B;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#B8860B\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DAA520;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#DAA520\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFD700;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFD700\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F0E68C;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#F0E68C\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#EEE8AA;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#EEE8AA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFEBCD;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFEBCD\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFE4B5;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFE4B5\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F5DEB3;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#F5DEB3\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFDEAD;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFDEAD\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DEB887;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#DEB887\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#D2B48C;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#D2B48C\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#BC8F8F;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#BC8F8F\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#A0522D;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#A0522D\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#8B4513;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#8B4513\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#D2691E;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#D2691E\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#CD853F;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#CD853F\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F4A460;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#F4A460\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#8B0000;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#8B0000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#800000;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#800000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#A52A2A;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#A52A2A\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#B22222;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#B22222\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#CD5C5C;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#CD5C5C\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F08080;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#F08080\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FA8072;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FA8072\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#E9967A;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#E9967A\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFA07A;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFA07A\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF7F50;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FF7F50\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF6347;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FF6347\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF8C00;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FF8C00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFA500;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFA500\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF4500;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FF4500\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DC143C;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#DC143C\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF0000;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FF0000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF1493;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FF1493\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF00FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FF00FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF69B4;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FF69B4\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFB6C1;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFB6C1\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFC0CB;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFC0CB\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DB7093;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#DB7093\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#C71585;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#C71585\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#800080;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#800080\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#8B008B;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#8B008B\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#9370DB;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#9370DB\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#8A2BE2;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#8A2BE2\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#4B0082;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#4B0082\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#9400D3;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#9400D3\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#9932CC;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#9932CC\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#BA55D3;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#BA55D3\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DA70D6;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#DA70D6\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#EE82EE;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#EE82EE\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DDA0DD;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#DDA0DD\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#D8BFD8;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#D8BFD8\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#E6E6FA;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#E6E6FA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F8F8FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#F8F8FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F0F8FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#F0F8FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F5FFFA;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#F5FFFA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F0FFF0;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#F0FFF0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FAFAD2;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FAFAD2\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFACD;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFFACD\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFF8DC;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFF8DC\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFFE0;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFFFE0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFFF0;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFFFF0\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFAF0;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFFAF0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FAF0E6;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FAF0E6\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FDF5E6;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FDF5E6\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FAEBD7;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FAEBD7\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFE4C4;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFE4C4\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFDAB9;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFDAB9\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFEFD5;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFEFD5\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFF5EE;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFF5EE\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFF0F5;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFF0F5\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFE4E1;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_TEXTCOLOR_END\', \'#FFE4E1\');">&nbsp;</td></table>';
var KE_BGCOLOR_value = '<table cellpadding="0" cellspacing="2" border="0"><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF0000;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FF0000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFF00;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFFF00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FF00;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#00FF00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#00FFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#0000FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#0000FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF00FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FF00FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFFFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F5F5F5;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#F5F5F5\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DCDCDC;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#DCDCDC\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFAFA;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFFAFA\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#D3D3D3;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#D3D3D3\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#C0C0C0;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#C0C0C0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#A9A9A9;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#A9A9A9\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#808080;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#808080\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#696969;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#696969\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#000000;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#000000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#2F4F4F;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#2F4F4F\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#708090;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#708090\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#778899;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#778899\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#4682B4;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#4682B4\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#4169E1;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#4169E1\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#6495ED;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#6495ED\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#B0C4DE;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#B0C4DE\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#7B68EE;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#7B68EE\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#6A5ACD;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#6A5ACD\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#483D8B;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#483D8B\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#191970;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#191970\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#000080;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#000080\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00008B;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#00008B\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#0000CD;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#0000CD\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#1E90FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#1E90FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00BFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#00BFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#87CEFA;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#87CEFA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#87CEEB;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#87CEEB\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#ADD8E6;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#ADD8E6\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#B0E0E6;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#B0E0E6\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F0FFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#F0FFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#E0FFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#E0FFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#AFEEEE;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#AFEEEE\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00CED1;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#00CED1\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#5F9EA0;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#5F9EA0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#48D1CC;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#48D1CC\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#00FFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#40E0D0;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#40E0D0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#20B2AA;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#20B2AA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#008B8B;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#008B8B\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#008080;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#008080\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#7FFFD4;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#7FFFD4\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#66CDAA;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#66CDAA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#8FBC8F;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#8FBC8F\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#3CB371;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#3CB371\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#2E8B57;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#2E8B57\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#006400;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#006400\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#008000;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#008000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#228B22;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#228B22\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#32CD32;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#32CD32\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FF00;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#00FF00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#7FFF00;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#7FFF00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#7CFC00;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#7CFC00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#ADFF2F;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#ADFF2F\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#98FB98;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#98FB98\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#90EE90;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#90EE90\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FF7F;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#00FF7F\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FA9A;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#00FA9A\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#556B2F;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#556B2F\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#6B8E23;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#6B8E23\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#808000;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#808000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#BDB76B;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#BDB76B\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#B8860B;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#B8860B\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DAA520;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#DAA520\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFD700;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFD700\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F0E68C;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#F0E68C\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#EEE8AA;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#EEE8AA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFEBCD;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFEBCD\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFE4B5;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFE4B5\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F5DEB3;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#F5DEB3\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFDEAD;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFDEAD\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DEB887;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#DEB887\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#D2B48C;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#D2B48C\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#BC8F8F;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#BC8F8F\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#A0522D;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#A0522D\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#8B4513;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#8B4513\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#D2691E;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#D2691E\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#CD853F;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#CD853F\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F4A460;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#F4A460\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#8B0000;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#8B0000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#800000;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#800000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#A52A2A;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#A52A2A\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#B22222;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#B22222\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#CD5C5C;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#CD5C5C\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F08080;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#F08080\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FA8072;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FA8072\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#E9967A;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#E9967A\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFA07A;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFA07A\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF7F50;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FF7F50\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF6347;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FF6347\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF8C00;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FF8C00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFA500;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFA500\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF4500;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FF4500\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DC143C;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#DC143C\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF0000;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FF0000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF1493;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FF1493\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF00FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FF00FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF69B4;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FF69B4\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFB6C1;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFB6C1\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFC0CB;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFC0CB\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DB7093;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#DB7093\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#C71585;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#C71585\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#800080;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#800080\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#8B008B;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#8B008B\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#9370DB;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#9370DB\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#8A2BE2;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#8A2BE2\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#4B0082;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#4B0082\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#9400D3;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#9400D3\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#9932CC;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#9932CC\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#BA55D3;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#BA55D3\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DA70D6;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#DA70D6\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#EE82EE;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#EE82EE\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DDA0DD;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#DDA0DD\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#D8BFD8;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#D8BFD8\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#E6E6FA;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#E6E6FA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F8F8FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#F8F8FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F0F8FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#F0F8FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F5FFFA;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#F5FFFA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F0FFF0;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#F0FFF0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FAFAD2;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FAFAD2\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFACD;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFFACD\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFF8DC;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFF8DC\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFFE0;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFFFE0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFFF0;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFFFF0\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFAF0;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFFAF0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FAF0E6;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FAF0E6\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FDF5E6;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FDF5E6\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FAEBD7;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FAEBD7\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFE4C4;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFE4C4\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFDAB9;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFDAB9\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFEFD5;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFEFD5\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFF5EE;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFF5EE\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFF0F5;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFF0F5\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFE4E1;" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_BGCOLOR_END\', \'#FFE4E1\');">&nbsp;</td></table>';
var KE_LAYER_value = '<div id="divPreview" style="margin:5px 2px 5px 2px;height:20px;border:1px solid #AAAAAA;font-size:1px;background-color:#FFFFFF;"></div><table cellpadding="0" cellspacing="2" border="0"><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF0000;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FF0000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFF00;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFFF00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FF00;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#00FF00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#00FFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#0000FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#0000FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF00FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FF00FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFFFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F5F5F5;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#F5F5F5\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DCDCDC;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#DCDCDC\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFAFA;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFFAFA\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#D3D3D3;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#D3D3D3\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#C0C0C0;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#C0C0C0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#A9A9A9;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#A9A9A9\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#808080;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#808080\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#696969;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#696969\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#000000;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#000000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#2F4F4F;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#2F4F4F\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#708090;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#708090\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#778899;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#778899\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#4682B4;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#4682B4\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#4169E1;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#4169E1\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#6495ED;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#6495ED\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#B0C4DE;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#B0C4DE\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#7B68EE;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#7B68EE\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#6A5ACD;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#6A5ACD\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#483D8B;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#483D8B\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#191970;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#191970\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#000080;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#000080\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00008B;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#00008B\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#0000CD;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#0000CD\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#1E90FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#1E90FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00BFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#00BFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#87CEFA;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#87CEFA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#87CEEB;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#87CEEB\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#ADD8E6;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#ADD8E6\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#B0E0E6;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#B0E0E6\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F0FFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#F0FFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#E0FFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#E0FFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#AFEEEE;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#AFEEEE\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00CED1;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#00CED1\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#5F9EA0;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#5F9EA0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#48D1CC;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#48D1CC\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#00FFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#40E0D0;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#40E0D0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#20B2AA;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#20B2AA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#008B8B;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#008B8B\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#008080;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#008080\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#7FFFD4;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#7FFFD4\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#66CDAA;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#66CDAA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#8FBC8F;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#8FBC8F\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#3CB371;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#3CB371\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#2E8B57;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#2E8B57\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#006400;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#006400\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#008000;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#008000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#228B22;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#228B22\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#32CD32;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#32CD32\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FF00;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#00FF00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#7FFF00;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#7FFF00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#7CFC00;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#7CFC00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#ADFF2F;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#ADFF2F\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#98FB98;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#98FB98\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#90EE90;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#90EE90\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FF7F;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#00FF7F\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FA9A;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#00FA9A\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#556B2F;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#556B2F\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#6B8E23;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#6B8E23\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#808000;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#808000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#BDB76B;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#BDB76B\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#B8860B;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#B8860B\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DAA520;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#DAA520\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFD700;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFD700\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F0E68C;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#F0E68C\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#EEE8AA;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#EEE8AA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFEBCD;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFEBCD\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFE4B5;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFE4B5\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F5DEB3;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#F5DEB3\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFDEAD;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFDEAD\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DEB887;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#DEB887\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#D2B48C;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#D2B48C\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#BC8F8F;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#BC8F8F\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#A0522D;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#A0522D\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#8B4513;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#8B4513\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#D2691E;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#D2691E\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#CD853F;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#CD853F\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F4A460;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#F4A460\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#8B0000;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#8B0000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#800000;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#800000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#A52A2A;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#A52A2A\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#B22222;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#B22222\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#CD5C5C;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#CD5C5C\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F08080;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#F08080\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FA8072;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FA8072\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#E9967A;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#E9967A\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFA07A;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFA07A\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF7F50;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FF7F50\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF6347;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FF6347\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF8C00;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FF8C00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFA500;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFA500\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF4500;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FF4500\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DC143C;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#DC143C\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF0000;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FF0000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF1493;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FF1493\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF00FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FF00FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF69B4;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FF69B4\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFB6C1;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFB6C1\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFC0CB;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFC0CB\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DB7093;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#DB7093\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#C71585;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#C71585\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#800080;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#800080\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#8B008B;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#8B008B\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#9370DB;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#9370DB\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#8A2BE2;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#8A2BE2\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#4B0082;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#4B0082\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#9400D3;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#9400D3\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#9932CC;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#9932CC\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#BA55D3;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#BA55D3\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DA70D6;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#DA70D6\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#EE82EE;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#EE82EE\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DDA0DD;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#DDA0DD\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#D8BFD8;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#D8BFD8\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#E6E6FA;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#E6E6FA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F8F8FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#F8F8FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F0F8FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#F0F8FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F5FFFA;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#F5FFFA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F0FFF0;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#F0FFF0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FAFAD2;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FAFAD2\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFACD;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFFACD\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFF8DC;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFF8DC\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFFE0;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFFFE0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFFF0;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFFFF0\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFAF0;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFFAF0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FAF0E6;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FAF0E6\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FDF5E6;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FDF5E6\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FAEBD7;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FAEBD7\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFE4C4;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFE4C4\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFDAB9;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFDAB9\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFEFD5;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFEFD5\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFF5EE;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFF5EE\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFF0F5;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFF0F5\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFE4E1;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'divPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_LAYER_END\', \'#FFE4E1\');">&nbsp;</td></table>';
var KE_TABLE_value = '<table cellpadding="0" cellspacing="0" style=" font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 0px #AAAAAA; "><tr><td id="kindTableTd1_1" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'1,1\');" onmouseover="javascript:KindDrawTableSelected(\'1\', \'1\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd1_2" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'1,2\');" onmouseover="javascript:KindDrawTableSelected(\'1\', \'2\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd1_3" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'1,3\');" onmouseover="javascript:KindDrawTableSelected(\'1\', \'3\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd1_4" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'1,4\');" onmouseover="javascript:KindDrawTableSelected(\'1\', \'4\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd1_5" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'1,5\');" onmouseover="javascript:KindDrawTableSelected(\'1\', \'5\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd1_6" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'1,6\');" onmouseover="javascript:KindDrawTableSelected(\'1\', \'6\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd1_7" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'1,7\');" onmouseover="javascript:KindDrawTableSelected(\'1\', \'7\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd1_8" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'1,8\');" onmouseover="javascript:KindDrawTableSelected(\'1\', \'8\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd1_9" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'1,9\');" onmouseover="javascript:KindDrawTableSelected(\'1\', \'9\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd1_10" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'1,10\');" onmouseover="javascript:KindDrawTableSelected(\'1\', \'10\');" onmouseout="javascript:;">&nbsp;</td></tr><tr><td id="kindTableTd2_1" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'2,1\');" onmouseover="javascript:KindDrawTableSelected(\'2\', \'1\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd2_2" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'2,2\');" onmouseover="javascript:KindDrawTableSelected(\'2\', \'2\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd2_3" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'2,3\');" onmouseover="javascript:KindDrawTableSelected(\'2\', \'3\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd2_4" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'2,4\');" onmouseover="javascript:KindDrawTableSelected(\'2\', \'4\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd2_5" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'2,5\');" onmouseover="javascript:KindDrawTableSelected(\'2\', \'5\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd2_6" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'2,6\');" onmouseover="javascript:KindDrawTableSelected(\'2\', \'6\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd2_7" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'2,7\');" onmouseover="javascript:KindDrawTableSelected(\'2\', \'7\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd2_8" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'2,8\');" onmouseover="javascript:KindDrawTableSelected(\'2\', \'8\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd2_9" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'2,9\');" onmouseover="javascript:KindDrawTableSelected(\'2\', \'9\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd2_10" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'2,10\');" onmouseover="javascript:KindDrawTableSelected(\'2\', \'10\');" onmouseout="javascript:;">&nbsp;</td></tr><tr><td id="kindTableTd3_1" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'3,1\');" onmouseover="javascript:KindDrawTableSelected(\'3\', \'1\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd3_2" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'3,2\');" onmouseover="javascript:KindDrawTableSelected(\'3\', \'2\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd3_3" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'3,3\');" onmouseover="javascript:KindDrawTableSelected(\'3\', \'3\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd3_4" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'3,4\');" onmouseover="javascript:KindDrawTableSelected(\'3\', \'4\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd3_5" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'3,5\');" onmouseover="javascript:KindDrawTableSelected(\'3\', \'5\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd3_6" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'3,6\');" onmouseover="javascript:KindDrawTableSelected(\'3\', \'6\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd3_7" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'3,7\');" onmouseover="javascript:KindDrawTableSelected(\'3\', \'7\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd3_8" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'3,8\');" onmouseover="javascript:KindDrawTableSelected(\'3\', \'8\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd3_9" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'3,9\');" onmouseover="javascript:KindDrawTableSelected(\'3\', \'9\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd3_10" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'3,10\');" onmouseover="javascript:KindDrawTableSelected(\'3\', \'10\');" onmouseout="javascript:;">&nbsp;</td></tr><tr><td id="kindTableTd4_1" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'4,1\');" onmouseover="javascript:KindDrawTableSelected(\'4\', \'1\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd4_2" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'4,2\');" onmouseover="javascript:KindDrawTableSelected(\'4\', \'2\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd4_3" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'4,3\');" onmouseover="javascript:KindDrawTableSelected(\'4\', \'3\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd4_4" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'4,4\');" onmouseover="javascript:KindDrawTableSelected(\'4\', \'4\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd4_5" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'4,5\');" onmouseover="javascript:KindDrawTableSelected(\'4\', \'5\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd4_6" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'4,6\');" onmouseover="javascript:KindDrawTableSelected(\'4\', \'6\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd4_7" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'4,7\');" onmouseover="javascript:KindDrawTableSelected(\'4\', \'7\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd4_8" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'4,8\');" onmouseover="javascript:KindDrawTableSelected(\'4\', \'8\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd4_9" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'4,9\');" onmouseover="javascript:KindDrawTableSelected(\'4\', \'9\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd4_10" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'4,10\');" onmouseover="javascript:KindDrawTableSelected(\'4\', \'10\');" onmouseout="javascript:;">&nbsp;</td></tr><tr><td id="kindTableTd5_1" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'5,1\');" onmouseover="javascript:KindDrawTableSelected(\'5\', \'1\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd5_2" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'5,2\');" onmouseover="javascript:KindDrawTableSelected(\'5\', \'2\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd5_3" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'5,3\');" onmouseover="javascript:KindDrawTableSelected(\'5\', \'3\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd5_4" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'5,4\');" onmouseover="javascript:KindDrawTableSelected(\'5\', \'4\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd5_5" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'5,5\');" onmouseover="javascript:KindDrawTableSelected(\'5\', \'5\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd5_6" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'5,6\');" onmouseover="javascript:KindDrawTableSelected(\'5\', \'6\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd5_7" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'5,7\');" onmouseover="javascript:KindDrawTableSelected(\'5\', \'7\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd5_8" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'5,8\');" onmouseover="javascript:KindDrawTableSelected(\'5\', \'8\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd5_9" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'5,9\');" onmouseover="javascript:KindDrawTableSelected(\'5\', \'9\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd5_10" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'5,10\');" onmouseover="javascript:KindDrawTableSelected(\'5\', \'10\');" onmouseout="javascript:;">&nbsp;</td></tr><tr><td id="kindTableTd6_1" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'6,1\');" onmouseover="javascript:KindDrawTableSelected(\'6\', \'1\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd6_2" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'6,2\');" onmouseover="javascript:KindDrawTableSelected(\'6\', \'2\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd6_3" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'6,3\');" onmouseover="javascript:KindDrawTableSelected(\'6\', \'3\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd6_4" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'6,4\');" onmouseover="javascript:KindDrawTableSelected(\'6\', \'4\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd6_5" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'6,5\');" onmouseover="javascript:KindDrawTableSelected(\'6\', \'5\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd6_6" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'6,6\');" onmouseover="javascript:KindDrawTableSelected(\'6\', \'6\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd6_7" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'6,7\');" onmouseover="javascript:KindDrawTableSelected(\'6\', \'7\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd6_8" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'6,8\');" onmouseover="javascript:KindDrawTableSelected(\'6\', \'8\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd6_9" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'6,9\');" onmouseover="javascript:KindDrawTableSelected(\'6\', \'9\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd6_10" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'6,10\');" onmouseover="javascript:KindDrawTableSelected(\'6\', \'10\');" onmouseout="javascript:;">&nbsp;</td></tr><tr><td id="kindTableTd7_1" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'7,1\');" onmouseover="javascript:KindDrawTableSelected(\'7\', \'1\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd7_2" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'7,2\');" onmouseover="javascript:KindDrawTableSelected(\'7\', \'2\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd7_3" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'7,3\');" onmouseover="javascript:KindDrawTableSelected(\'7\', \'3\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd7_4" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'7,4\');" onmouseover="javascript:KindDrawTableSelected(\'7\', \'4\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd7_5" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'7,5\');" onmouseover="javascript:KindDrawTableSelected(\'7\', \'5\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd7_6" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'7,6\');" onmouseover="javascript:KindDrawTableSelected(\'7\', \'6\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd7_7" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'7,7\');" onmouseover="javascript:KindDrawTableSelected(\'7\', \'7\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd7_8" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'7,8\');" onmouseover="javascript:KindDrawTableSelected(\'7\', \'8\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd7_9" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'7,9\');" onmouseover="javascript:KindDrawTableSelected(\'7\', \'9\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd7_10" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'7,10\');" onmouseover="javascript:KindDrawTableSelected(\'7\', \'10\');" onmouseout="javascript:;">&nbsp;</td></tr><tr><td id="kindTableTd8_1" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'8,1\');" onmouseover="javascript:KindDrawTableSelected(\'8\', \'1\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd8_2" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'8,2\');" onmouseover="javascript:KindDrawTableSelected(\'8\', \'2\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd8_3" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'8,3\');" onmouseover="javascript:KindDrawTableSelected(\'8\', \'3\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd8_4" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'8,4\');" onmouseover="javascript:KindDrawTableSelected(\'8\', \'4\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd8_5" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'8,5\');" onmouseover="javascript:KindDrawTableSelected(\'8\', \'5\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd8_6" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'8,6\');" onmouseover="javascript:KindDrawTableSelected(\'8\', \'6\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd8_7" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'8,7\');" onmouseover="javascript:KindDrawTableSelected(\'8\', \'7\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd8_8" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'8,8\');" onmouseover="javascript:KindDrawTableSelected(\'8\', \'8\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd8_9" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'8,9\');" onmouseover="javascript:KindDrawTableSelected(\'8\', \'9\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd8_10" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'8,10\');" onmouseover="javascript:KindDrawTableSelected(\'8\', \'10\');" onmouseout="javascript:;">&nbsp;</td></tr><tr><td id="kindTableTd9_1" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'9,1\');" onmouseover="javascript:KindDrawTableSelected(\'9\', \'1\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd9_2" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'9,2\');" onmouseover="javascript:KindDrawTableSelected(\'9\', \'2\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd9_3" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'9,3\');" onmouseover="javascript:KindDrawTableSelected(\'9\', \'3\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd9_4" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'9,4\');" onmouseover="javascript:KindDrawTableSelected(\'9\', \'4\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd9_5" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'9,5\');" onmouseover="javascript:KindDrawTableSelected(\'9\', \'5\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd9_6" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'9,6\');" onmouseover="javascript:KindDrawTableSelected(\'9\', \'6\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd9_7" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'9,7\');" onmouseover="javascript:KindDrawTableSelected(\'9\', \'7\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd9_8" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'9,8\');" onmouseover="javascript:KindDrawTableSelected(\'9\', \'8\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd9_9" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'9,9\');" onmouseover="javascript:KindDrawTableSelected(\'9\', \'9\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd9_10" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'9,10\');" onmouseover="javascript:KindDrawTableSelected(\'9\', \'10\');" onmouseout="javascript:;">&nbsp;</td></tr><tr><td id="kindTableTd10_1" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'10,1\');" onmouseover="javascript:KindDrawTableSelected(\'10\', \'1\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd10_2" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'10,2\');" onmouseover="javascript:KindDrawTableSelected(\'10\', \'2\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd10_3" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'10,3\');" onmouseover="javascript:KindDrawTableSelected(\'10\', \'3\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd10_4" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'10,4\');" onmouseover="javascript:KindDrawTableSelected(\'10\', \'4\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd10_5" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'10,5\');" onmouseover="javascript:KindDrawTableSelected(\'10\', \'5\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd10_6" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'10,6\');" onmouseover="javascript:KindDrawTableSelected(\'10\', \'6\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd10_7" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'10,7\');" onmouseover="javascript:KindDrawTableSelected(\'10\', \'7\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd10_8" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'10,8\');" onmouseover="javascript:KindDrawTableSelected(\'10\', \'8\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd10_9" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'10,9\');" onmouseover="javascript:KindDrawTableSelected(\'10\', \'9\');" onmouseout="javascript:;">&nbsp;</td><td id="kindTableTd10_10" style="width:15px;height:15px;background-color:#FFFFFF;border:1px solid #DDDDDD;cursor:pointer;" onclick="javascript:KindExecute(\'KE_TABLE_END\', \'10,10\');" onmouseover="javascript:KindDrawTableSelected(\'10\', \'10\');" onmouseout="javascript:;">&nbsp;</td></tr><tr><td colspan="10" id="tableLocation" style="text-align:center;height:20px;"></td></tr></table>';
var KE_HR_value = '<div id="hrPreview" style="margin:10px 2px 10px 2px;height:1px;border:0;font-size:0;background-color:#FFFFFF;"></div><table cellpadding="0" cellspacing="2" border="0"><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF0000;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FF0000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFF00;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFFF00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FF00;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#00FF00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#00FFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#0000FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#0000FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF00FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FF00FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFFFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F5F5F5;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#F5F5F5\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DCDCDC;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#DCDCDC\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFAFA;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFFAFA\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#D3D3D3;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#D3D3D3\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#C0C0C0;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#C0C0C0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#A9A9A9;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#A9A9A9\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#808080;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#808080\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#696969;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#696969\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#000000;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#000000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#2F4F4F;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#2F4F4F\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#708090;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#708090\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#778899;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#778899\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#4682B4;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#4682B4\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#4169E1;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#4169E1\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#6495ED;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#6495ED\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#B0C4DE;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#B0C4DE\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#7B68EE;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#7B68EE\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#6A5ACD;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#6A5ACD\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#483D8B;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#483D8B\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#191970;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#191970\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#000080;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#000080\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00008B;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#00008B\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#0000CD;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#0000CD\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#1E90FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#1E90FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00BFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#00BFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#87CEFA;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#87CEFA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#87CEEB;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#87CEEB\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#ADD8E6;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#ADD8E6\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#B0E0E6;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#B0E0E6\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F0FFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#F0FFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#E0FFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#E0FFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#AFEEEE;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#AFEEEE\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00CED1;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#00CED1\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#5F9EA0;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#5F9EA0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#48D1CC;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#48D1CC\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FFFF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#00FFFF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#40E0D0;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#40E0D0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#20B2AA;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#20B2AA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#008B8B;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#008B8B\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#008080;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#008080\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#7FFFD4;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#7FFFD4\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#66CDAA;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#66CDAA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#8FBC8F;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#8FBC8F\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#3CB371;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#3CB371\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#2E8B57;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#2E8B57\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#006400;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#006400\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#008000;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#008000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#228B22;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#228B22\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#32CD32;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#32CD32\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FF00;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#00FF00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#7FFF00;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#7FFF00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#7CFC00;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#7CFC00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#ADFF2F;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#ADFF2F\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#98FB98;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#98FB98\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#90EE90;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#90EE90\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FF7F;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#00FF7F\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#00FA9A;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#00FA9A\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#556B2F;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#556B2F\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#6B8E23;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#6B8E23\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#808000;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#808000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#BDB76B;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#BDB76B\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#B8860B;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#B8860B\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DAA520;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#DAA520\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFD700;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFD700\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F0E68C;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#F0E68C\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#EEE8AA;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#EEE8AA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFEBCD;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFEBCD\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFE4B5;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFE4B5\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F5DEB3;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#F5DEB3\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFDEAD;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFDEAD\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DEB887;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#DEB887\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#D2B48C;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#D2B48C\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#BC8F8F;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#BC8F8F\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#A0522D;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#A0522D\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#8B4513;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#8B4513\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#D2691E;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#D2691E\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#CD853F;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#CD853F\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F4A460;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#F4A460\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#8B0000;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#8B0000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#800000;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#800000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#A52A2A;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#A52A2A\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#B22222;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#B22222\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#CD5C5C;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#CD5C5C\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F08080;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#F08080\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FA8072;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FA8072\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#E9967A;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#E9967A\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFA07A;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFA07A\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF7F50;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FF7F50\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF6347;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FF6347\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF8C00;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FF8C00\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFA500;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFA500\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF4500;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FF4500\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DC143C;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#DC143C\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF0000;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FF0000\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF1493;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FF1493\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF00FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FF00FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FF69B4;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FF69B4\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFB6C1;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFB6C1\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFC0CB;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFC0CB\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DB7093;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#DB7093\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#C71585;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#C71585\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#800080;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#800080\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#8B008B;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#8B008B\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#9370DB;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#9370DB\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#8A2BE2;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#8A2BE2\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#4B0082;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#4B0082\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#9400D3;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#9400D3\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#9932CC;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#9932CC\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#BA55D3;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#BA55D3\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DA70D6;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#DA70D6\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#EE82EE;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#EE82EE\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#DDA0DD;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#DDA0DD\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#D8BFD8;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#D8BFD8\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#E6E6FA;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#E6E6FA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F8F8FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#F8F8FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F0F8FF;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#F0F8FF\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F5FFFA;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#F5FFFA\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#F0FFF0;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#F0FFF0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FAFAD2;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FAFAD2\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFACD;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFFACD\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFF8DC;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFF8DC\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFFE0;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFFFE0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFFF0;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFFFF0\');">&nbsp;</td><tr><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFFAF0;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFFAF0\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FAF0E6;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FAF0E6\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FDF5E6;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FDF5E6\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FAEBD7;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FAEBD7\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFE4C4;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFE4C4\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFDAB9;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFDAB9\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFEFD5;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFEFD5\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFF5EE;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFF5EE\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFF0F5;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFF0F5\');">&nbsp;</td><td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:#FFE4E1;" onmouseover="javascript:this.style.borderColor=\'#000000\';document.getElementById(\'hrPreview\').style.backgroundColor = this.style.backgroundColor;" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" onclick="javascript:KindExecute(\'KE_HR_END\', \'#FFE4E1\');">&nbsp;</td></table>';
var KE_SPECIALCHAR_value = '<table cellpadding="0" cellspacing="2" style=" font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 0px #AAAAAA; "><tr><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><tr><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><tr><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><tr><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><tr><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><tr><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><tr><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><tr><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><tr><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><tr><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td><td style="padding:2px;border:1px solid #AAAAAA;cursor:pointer;" onclick="javascript:KindExecute(\'KE_SPECIALCHAR_END\', \'��\');" onmouseover="javascript:this.style.borderColor=\'#000000\';" onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';">��</td></table>';



var KE_ZOOM_str = '<div id="POPUP_KE_ZOOM" style="position:absolute;top:1px;left:1px;font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 1px #AAAAAA;z-index:1;display:none;"></div>';
var KE_TITLE_str = '<div id="POPUP_KE_TITLE" style="position:absolute;top:1px;left:1px;font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 1px #AAAAAA;z-index:1;display:none;"></div>';
var KE_FONTNAME_str = '<div id="POPUP_KE_FONTNAME" style="position:absolute;top:1px;left:1px;font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 1px #AAAAAA;z-index:1;display:none;"></div>';
var KE_FONTSIZE_str = '<div id="POPUP_KE_FONTSIZE" style="position:absolute;top:1px;left:1px;font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 1px #AAAAAA;z-index:1;display:none;"></div>';
var KE_TEXTCOLOR_str = '<div id="POPUP_KE_TEXTCOLOR" style="width:160px;padding:2px;position:absolute;top:1px;left:1px;font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 1px #AAAAAA;z-index:1;display:none;"></div>';
var KE_BGCOLOR_str = '<div id="POPUP_KE_BGCOLOR" style="width:160px;padding:2px;position:absolute;top:1px;left:1px;font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 1px #AAAAAA;z-index:1;display:none;"></div>';
var KE_LAYER_str = '<div id="POPUP_KE_LAYER" style="width:160px;position:absolute;top:1px;left:1px;font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 1px #AAAAAA;z-index:1;display:none;"></div>';
var KE_TABLE_str = '<div id="POPUP_KE_TABLE"  style="position:absolute;top:1px;left:1px;font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 1px #AAAAAA;z-index:1;display:none;"> </div>';
var KE_HR_str = '<div id="POPUP_KE_HR" style="width:160px;position:absolute;top:1px;left:1px;font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 1px #AAAAAA;z-index:1;display:none;"></div>';
var KE_ICON_str = '<div id="POPUP_KE_ICON"  style="position:absolute;top:1px;left:1px;font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 1px #AAAAAA;z-index:1;display:none;"> </div>';
var KE_SPECIALCHAR_str = '<div id="POPUP_KE_SPECIALCHAR"  style="position:absolute;top:1px;left:1px;font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 1px #AAAAAA;z-index:1;display:none;"> </div>';
var KE_ABOUT_str = '<div id="POPUP_KE_ABOUT" style="width:230px;position:absolute;top:1px;left:1px;font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 1px #AAAAAA;z-index:1;display:none;;padding:5px;"><span style="margin-right:10px;">KindEditor 2.5.4</span><a href="http://www.kindsoft.net/" target="_blank" style="color:#4169e1;" onclick="javascript:KindDisableMenu();">���ʼ���֧����վ</a><br /></div>';
var KE_IMAGE_str = '<div id="POPUP_KE_IMAGE" style="width:250px;position:absolute;top:1px;left:1px;font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 1px #AAAAAA;z-index:1;display:none;"><iframe name="KindImageIframe" id="KindImageIframe" frameborder="0" style="width:250px;height:150px;padding:0;margin:0;border:0;"></iframe></div>';
var KE_FLV_str = '<div id="POPUP_KE_FLV" style="width:250px;position:absolute;top:1px;left:1px;font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 1px #AAAAAA;z-index:1;display:none;"><iframe name="KindImageP8FLVIframe" id="KindImageP8FLVIframe" frameborder="0" style="width:250px;height:100px;padding:0;margin:0;border:0;"></iframe></div>';
var KE_MYFILES_str = '<div id="POPUP_KE_MYFILES" style="width:250px;position:absolute;top:1px;left:1px;font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 1px #AAAAAA;z-index:1;display:none;"><iframe name="KindImageP8MYFILESIframe" id="KindImageP8MYFILESIframe" frameborder="0" style="width:250px;height:100px;padding:0;margin:0;border:0;"></iframe></div>';
var KE_FLASH_str = '<div id="POPUP_KE_FLASH" style="width:250px;position:absolute;top:1px;left:1px;font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 1px #AAAAAA;z-index:1;display:none;"><iframe name="KindFlashIframe" id="KindFlashIframe" frameborder="0" style="width:250px;height:100px;padding:0;margin:0;border:0;"></iframe></div>';
var KE_MEDIA_str = '<div id="POPUP_KE_MEDIA" style="width:250px;position:absolute;top:1px;left:1px;font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 1px #AAAAAA;z-index:1;display:none;"><iframe name="KindMediaIframe" id="KindMediaIframe" frameborder="0" style="width:250px;height:100px;padding:0;margin:0;border:0;"></iframe></div>';
var KE_REAL_str = '<div id="POPUP_KE_REAL" style="width:250px;position:absolute;top:1px;left:1px;font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 1px #AAAAAA;z-index:1;display:none;"><iframe name="KindRealIframe" id="KindRealIframe" frameborder="0" style="width:250px;height:100px;padding:0;margin:0;border:0;"></iframe></div>';
var KE_LINK_str = '<div id="POPUP_KE_LINK" style="width:250px;position:absolute;top:1px;left:1px;font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 1px #AAAAAA;z-index:1;display:none;"><iframe name="KindLinkIframe" id="KindLinkIframe" frameborder="0" style="width:250px;height:85px;padding:0;margin:0;border:0;"></iframe></div>';


var KE_VERSION = "2.5.4";
//var KE_EDITOR_TYPE = "full";		//full or simple
var KE_SAFE_MODE = false;			// true or false
var KE_UPLOAD_MODE = true;			// true or false
var KE_FONT_FAMILY = "Courier New";
var KE_WIDTH = "700px";
var KE_HEIGHT = "400px";
var KE_SITE_DOMAIN = "";
var KE_SKIN_PATH  = "/ewebeditor/default/";
var KE_ICON_PATH = "/images/default/faceicon/";
var KE_IMAGE_ATTACH_PATH = "/upload_files/";
var KE_IMAGE_UPLOAD_CGI = "/upfile_eweb.php";
var KE_CSS_PATH = "/ewebeditor/common.css";
var KE_MENU_BORDER_COLOR = '#AAAAAA';
var KE_MENU_BG_COLOR = '#EFEFEF';
var KE_MENU_TEXT_COLOR = '#222222';
var KE_MENU_SELECTED_COLOR = '#CCCCCC';
var KE_TOOLBAR_BORDER_COLOR = '#DDDDDD';
var KE_TOOLBAR_BG_COLOR = '#EFEFEF';
var KE_FORM_BORDER_COLOR = '#DDDDDD';
var KE_FORM_BG_COLOR = '#FFFFFF';
var KE_BUTTON_COLOR = '#AAAAAA';
var KE_LANG = {
	INPUT_URL		: "��������ȷ��URL��ַ��",
	SELECT_IMAGE	: "��ѡ��",
	INVALID_IMAGE	: "ֻ��ѡ��GIF,JPG,PNG,BMP��ʽ��ͼƬ��������ѡ��",
	INVALID_FLASH	: "ֻ��ѡ��swf��ʽ���ļ���������ѡ��",
	INVALID_MEDIA	: "ֻ��ѡ��MP3,WAV,WMA,WMV,MID,AVI,MPG,ASF��ʽ���ļ���������ѡ��",
	INVALID_REAL	: "ֻ��ѡ��RM,RMVB��ʽ���ļ���������ѡ��",
	INVALID_WIDTH	: "���Ȳ������֣����������롣",
	INVALID_HEIGHT	: "�߶Ȳ������֣����������롣",
	INVALID_BORDER	: "�߿������֣����������롣",
	INVALID_HSPACE	: "����������֣����������롣",
	INVALID_VSPACE	: "�����������֣����������롣",
	INPUT_CONTENT	: "����������",
	TITLE			: "����",
	WIDTH			: "��",
	HEIGHT			: "��",
	BORDER			: "��",
	ALIGN			: "���뷽ʽ",
	HSPACE			: "���",
	VSPACE			: "����",
	CONFIRM			: "ȷ��",
	CANCEL			: "ȡ��",
	PREVIEW			: "Ԥ��",
	LISTENING		: "����",
	LOCAL			: "����",
	REMOTE			: "Զ��",
	NEW_WINDOW		: "�´���",
	CURRENT_WINDOW	: "��ǰ����",
	TARGET			: "Ŀ��",
	ABOUT			: "���ʼ���֧����վ",
	SUBJECT			: "����"
}
var KE_FONT_NAME = Array(
	Array('SimSun', '����'), 
	Array('SimHei', '����'), 
	Array('FangSong_GB2312', '������'), 
	Array('KaiTi_GB2312', '����'), 
	Array('NSimSun', '������'), 
	Array('Arial', 'Arial'), 
	Array('Arial Black', 'Arial Black'), 
	Array('Times New Roman', 'Times New Roman'), 
	Array('Courier New', 'Courier New'), 
	Array('Tahoma', 'Tahoma'), 
	Array('Verdana', 'Verdana'), 
	Array('GulimChe', 'GulimChe'), 
	Array('MS Gothic', 'MS Gothic') 
);
var KE_SPECIAL_CHARACTER = Array(
	'��','��','��','��','��','��','��','��','��','��','��','��','��','��','��','��',
	'��','��','��','��','��','��','��','��','��','��','��','��','��','��','��','��',
	'��','��','��','��','��','��','��','��','��','��','��','��','��','��','��','��',
	'��','��','��','��','��','��','��','��','��','��','��','��','��','��','��','��',
	'��','��','��','��','��','��','��','��','��','��','��','��','��','��','��','��',
	'��','��','��','��','��','��','��','��','��','��','��','��','��','��',
	'��','��','��','��','��','��'
);
var KE_TOP_TOOLBAR_ICON = Array(
	Array('KE_SOURCE', 'source.gif', '��ͼת��'),
	Array('KE_PREVIEW', 'preview.gif', 'Ԥ��'),
	Array('KE_ZOOM', 'zoom.gif', '��ʾ����'),
	Array('KE_PRINT', 'print.gif', '��ӡ'),
	Array('KE_UNDO', 'undo.gif', '����'),
	Array('KE_REDO', 'redo.gif', 'ǰ��'),
	Array('KE_CUT', 'cut.gif', '����'),
	Array('KE_COPY', 'copy.gif', '����'),
	Array('KE_PASTE', 'paste.gif', 'ճ��'),
	Array('KE_SELECTALL', 'selectall.gif', 'ȫѡ'),
	Array('KE_JUSTIFYLEFT', 'justifyleft.gif', '�����'),
	Array('KE_JUSTIFYCENTER', 'justifycenter.gif', '����'),
	Array('KE_JUSTIFYRIGHT', 'justifyright.gif', '�Ҷ���'),
	Array('KE_JUSTIFYFULL', 'justifyfull.gif', '���˶���'),
	Array('KE_NUMBEREDLIST', 'numberedlist.gif', '���'),
	Array('KE_UNORDERLIST', 'unorderedlist.gif', '��Ŀ����'),
	Array('KE_INDENT', 'indent.gif', '��������'),
	Array('KE_OUTDENT', 'outdent.gif', '��������'),
	Array('KE_SUBSCRIPT', 'subscript.gif', '�±�'),
	Array('KE_SUPERSCRIPT', 'superscript.gif', '�ϱ�'),
	Array('KE_DATE', 'date.gif', '����'),
	Array('KE_TIME', 'time.gif', 'ʱ��'),
	Array('KE_BOKECC', 'bokecc.gif', 'CC��Ƶ')
);
var KE_BOTTOM_TOOLBAR_ICON = Array(
	Array('KE_TITLE', 'title.gif', '����'),
	Array('KE_FONTNAME', 'font.gif', '����'),
	Array('KE_FONTSIZE', 'fontsize.gif', '���ִ�С'),
	Array('KE_TEXTCOLOR', 'textcolor.gif', '������ɫ'),
	Array('KE_BGCOLOR', 'bgcolor.gif', '���ֱ���'),
	Array('KE_BOLD', 'bold.gif', '����'),
	Array('KE_ITALIC', 'italic.gif', 'б��'),
	Array('KE_UNDERLINE', 'underline.gif', '�»���'),
	Array('KE_STRIKE', 'strikethrough.gif', 'ɾ����'),
	Array('KE_REMOVE', 'removeformat.gif', 'ɾ����ʽ'),
	Array('KE_IMAGE', 'image.gif', 'ͼƬ'),
	Array('KE_FLV', 'flv.gif', 'flv��Ƶ'),
	Array('KE_MYFILES', 'file.gif', '�ļ�'),
	Array('KE_FLASH', 'flash.gif', 'Flash'),
	Array('KE_MEDIA', 'media.gif', 'Windows Media Player'),
	Array('KE_REAL', 'real.gif', 'Real Player'),
	Array('KE_LAYER', 'layer.gif', '��'),
	Array('KE_TABLE', 'table.gif', '����'),
	Array('KE_SPECIALCHAR', 'specialchar.gif', '�����ַ�'),
	Array('KE_HR', 'hr.gif', '����'),
	Array('KE_ICON', 'emoticons.gif', 'Ц��'),
	Array('KE_LINK', 'link.gif', '������������'),
	Array('KE_UNLINK', 'unlink.gif', 'ɾ����������')
);
var KE_SIMPLE_TOOLBAR_ICON = Array(
	Array('KE_FONTNAME', 'font.gif', '����'),
	Array('KE_FONTSIZE', 'fontsize.gif', '���ִ�С'),
	Array('KE_TEXTCOLOR', 'textcolor.gif', '������ɫ'),
	Array('KE_BGCOLOR', 'bgcolor.gif', '���ֱ���'),
	Array('KE_BOLD', 'bold.gif', '����'),
	Array('KE_ITALIC', 'italic.gif', 'б��'),
	Array('KE_UNDERLINE', 'underline.gif', '�»���'),
	Array('KE_JUSTIFYLEFT', 'justifyleft.gif', '�����'),
	Array('KE_JUSTIFYCENTER', 'justifycenter.gif', '����'),
	Array('KE_JUSTIFYRIGHT', 'justifyright.gif', '�Ҷ���'),
	Array('KE_LAYER', 'layer.gif', '��'),
	Array('KE_HR', 'hr.gif', '����'),
	Array('KE_ICON', 'emoticons.gif', 'Ц��'),
	Array('KE_LINK', 'link.gif', '������������')
);
var KE_TITLE_TABLE = Array(
	Array('H1', KE_LANG['SUBJECT'] + ' 1'), 
	Array('H2', KE_LANG['SUBJECT'] + ' 2'), 
	Array('H3', KE_LANG['SUBJECT'] + ' 3'), 
	Array('H4', KE_LANG['SUBJECT'] + ' 4'), 
	Array('H5', KE_LANG['SUBJECT'] + ' 5'), 
	Array('H6', KE_LANG['SUBJECT'] + ' 6')
);
var KE_ZOOM_TABLE = Array('250%', '200%', '150%', '120%', '100%', '80%', '50%');
var KE_FONT_SIZE = Array(
	Array(1,'8pt'), 
	Array(2,'10pt'), 
	Array(3,'12pt'), 
	Array(4,'14pt'), 
	Array(5,'18pt'), 
	Array(6,'24pt'), 
	Array(7,'36pt')
);
var KE_POPUP_MENU_TABLE = Array(
	"KE_ZOOM", "KE_TITLE", "KE_FONTNAME", "KE_FONTSIZE", "KE_TEXTCOLOR", "KE_BGCOLOR", 
	"KE_LAYER", "KE_TABLE", "KE_HR", "KE_ICON", "KE_SPECIALCHAR", "KE_ABOUT", 
	"KE_IMAGE", "KE_FLV", "KE_MYFILES",  "KE_FLASH", "KE_MEDIA", "KE_REAL", "KE_LINK"
);
var KE_COLOR_TABLE = Array(
	"#FF0000", "#FFFF00", "#00FF00", "#00FFFF", "#0000FF", "#FF00FF", "#FFFFFF", "#F5F5F5", "#DCDCDC", "#FFFAFA",
	"#D3D3D3", "#C0C0C0", "#A9A9A9", "#808080", "#696969", "#000000", "#2F4F4F", "#708090", "#778899", "#4682B4",
	"#4169E1", "#6495ED", "#B0C4DE", "#7B68EE", "#6A5ACD", "#483D8B", "#191970", "#000080", "#00008B", "#0000CD",
	"#1E90FF", "#00BFFF", "#87CEFA", "#87CEEB", "#ADD8E6", "#B0E0E6", "#F0FFFF", "#E0FFFF", "#AFEEEE", "#00CED1",
	"#5F9EA0", "#48D1CC", "#00FFFF", "#40E0D0", "#20B2AA", "#008B8B", "#008080", "#7FFFD4", "#66CDAA", "#8FBC8F",
	"#3CB371", "#2E8B57", "#006400", "#008000", "#228B22", "#32CD32", "#00FF00", "#7FFF00", "#7CFC00", "#ADFF2F",
	"#98FB98", "#90EE90", "#00FF7F", "#00FA9A", "#556B2F", "#6B8E23", "#808000", "#BDB76B", "#B8860B", "#DAA520",
	"#FFD700", "#F0E68C", "#EEE8AA", "#FFEBCD", "#FFE4B5", "#F5DEB3", "#FFDEAD", "#DEB887", "#D2B48C", "#BC8F8F",
	"#A0522D", "#8B4513", "#D2691E", "#CD853F", "#F4A460", "#8B0000", "#800000", "#A52A2A", "#B22222", "#CD5C5C",
	"#F08080", "#FA8072", "#E9967A", "#FFA07A", "#FF7F50", "#FF6347", "#FF8C00", "#FFA500", "#FF4500", "#DC143C",
	"#FF0000", "#FF1493", "#FF00FF", "#FF69B4", "#FFB6C1", "#FFC0CB", "#DB7093", "#C71585", "#800080", "#8B008B",
	"#9370DB", "#8A2BE2", "#4B0082", "#9400D3", "#9932CC", "#BA55D3", "#DA70D6", "#EE82EE", "#DDA0DD", "#D8BFD8",
	"#E6E6FA", "#F8F8FF", "#F0F8FF", "#F5FFFA", "#F0FFF0", "#FAFAD2", "#FFFACD", "#FFF8DC", "#FFFFE0", "#FFFFF0",
	"#FFFAF0", "#FAF0E6", "#FDF5E6", "#FAEBD7", "#FFE4C4", "#FFDAB9", "#FFEFD5", "#FFF5EE", "#FFF0F5", "#FFE4E1"
);
var KE_IMAGE_ALIGN_TABLE = Array(
	"baseline", "top", "middle", "bottom", "texttop", "absmiddle", "absbottom", "left", "right"
);
var KE_OBJ_NAME;
var KE_SELECTION;
var KE_RANGE;
var KE_RANGE_TEXT;
var KE_EDITFORM_DOCUMENT;
var KE_IMAGE_DOCUMENT;
var KE_FLV_DOCUMENT;
var KE_MYFILES_DOCUMENT;
var KE_FLASH_DOCUMENT;
var KE_MEDIA_DOCUMENT;
var KE_REAL_DOCUMENT;
var KE_LINK_DOCUMENT;
var KE_BROWSER;
var KE_TOOLBAR_ICON;
function KindGetBrowser()
{
	var browser = '';
	var agentInfo = navigator.userAgent.toLowerCase();
	if (agentInfo.indexOf("msie") > -1) {
		var re = new RegExp("msie\\s?([\\d\\.]+)","ig");
		var arr = re.exec(agentInfo);
		if (parseInt(RegExp.$1) >= 5.5) {
			browser = 'IE';
		}
	} else if (agentInfo.indexOf("firefox") > -1) {
		browser = 'FF';
	} else if (agentInfo.indexOf("netscape") > -1) {
		var temp1 = agentInfo.split(' ');
		var temp2 = temp1[temp1.length-1].split('/');
		if (parseInt(temp2[1]) >= 7) {
			browser = 'NS';
		}
	} else if (agentInfo.indexOf("gecko") > -1) {
		browser = 'ML';
	} else if (agentInfo.indexOf("opera") > -1) {
		var temp1 = agentInfo.split(' ');
		var temp2 = temp1[0].split('/');
		if (parseInt(temp2[1]) >= 9) {
			browser = 'OPERA';
		}
	}
	return browser;
}
function KindGetFileName(file, separator)
{
	var temp = file.split(separator);
	var len = temp.length;
	var fileName = temp[len-1];
	return fileName;
}
function KindGetFileExt(fileName)
{
	var temp = fileName.split(".");
	var len = temp.length;
	var fileExt = temp[len-1].toLowerCase();
	return fileExt;
}
function KindCheckImageFileType(file, separator)
{
	if (separator == "/" && file.match(/http:\/\/.{3,}/) == null) {
		alert(KE_LANG['INPUT_URL']);
		return false;
	}
	var fileName = KindGetFileName(file, separator);
	var fileExt = KindGetFileExt(fileName);
	if (fileExt != 'gif' && fileExt != 'jpg' && fileExt != 'png' && fileExt != 'bmp') {
		alert(KE_LANG['INVALID_IMAGE']);
		return false;
	}
	return true;
}

function KindCheckImageP8FLVFileType(file, separator,cmd)
{
	if (separator == "/" && file.match(/http:\/\/.{3,}/) == null) {
		alert(KE_LANG['INPUT_URL']);
		return false;
	}
	var fileName = KindGetFileName(file, separator);
	var fileExt = KindGetFileExt(fileName);

	if(cmd=='KE_FLV'){
		if (fileExt != 'flv') {
			alert(KE_LANG['INPUT_URL']);
			return false;
		}
	}else if(cmd=='KE_FLASH'){
		if (fileExt != 'swf') {
			alert(KE_LANG['INPUT_URL']);
			return false;
		}
	}else if(cmd=='KE_MEDIA'){
		if (fileExt != 'mp3' && fileExt != 'wav' && fileExt != 'wma' && fileExt != 'wmv' && fileExt != 'mid' && fileExt != 'avi' && fileExt != 'mpg' && fileExt != 'mpeg' && fileExt != 'asf') {
			alert(KE_LANG['INPUT_URL']);
			return false;
		}
	}else if(cmd=='KE_REAL'){
		if (fileExt != 'rm' && fileExt != 'ra' && fileExt != 'rmvb') {
			alert(KE_LANG['INPUT_URL']);
			return false;
		}
	}else if(cmd=='KE_MYFILES'){
		if (fileExt == 'php' || fileExt == 'asp' || fileExt == 'jsp' || fileExt == 'aspx' || fileExt == 'php3' || fileExt == 'cgi') {
			alert(KE_LANG['INPUT_URL']);
			return false;
		}
	}else{
		alert(KE_LANG['INPUT_URL']);
		return false;
	}
	return true;
}

function KindCheckFlashFileType(file, separator)
{
	if (file.match(/http:\/\/.{3,}/) == null) {
		alert(KE_LANG['INPUT_URL']);
		return false;
	}
	var fileName = KindGetFileName(file, "/");
	var fileExt = KindGetFileExt(fileName);
	if (fileExt != 'swf') {
		alert(KE_LANG['INVALID_FLASH']);
		return false;
	}
	return true;
}
function KindCheckMediaFileType(cmd, file, separator)
{
	if (file.match(/http:\/\/.{3,}/) == null) {
		alert(KE_LANG['INPUT_URL']);
		return false;
	}
	var fileName = KindGetFileName(file, "/");
	var fileExt = KindGetFileExt(fileName);
	if (cmd == 'KE_REAL') {
		if (fileExt != 'rm' && fileExt != 'rmvb') {
			alert(KE_LANG['INVALID_REAL']);
			return false;
		}
	} else {
		if (fileExt != 'mp3' && fileExt != 'wav' && fileExt != 'wma' && fileExt != 'wmv' && fileExt != 'mid' && fileExt != 'avi' && fileExt != 'mpg' && fileExt != 'asf') {
			alert(KE_LANG['INVALID_MEDIA']);
			return false;
		}
	}
	return true;
}
function KindHtmlToXhtml(str) 
{
	str = str.replace(/<br.*?>/gi, "<br />");
	str = str.replace(/(<hr\s+[^>]*[^\/])(>)/gi, "$1 />");
	str = str.replace(/(<img\s+[^>]*[^\/])(>)/gi, "$1 />");
	str = str.replace(/(<\w+)(.*?>)/gi, function ($0,$1,$2) {
						return($1.toLowerCase() + KindConvertAttribute($2));
					}
				);
	str = str.replace(/(<\/\w+>)/gi, function ($0,$1) {
						return($1.toLowerCase());
					}
				);
	return str;
}
function KindConvertAttribute(str)
{
	if (KE_SAFE_MODE == true) {
		str = KindClearAttributeScriptTag(str);
	}
	return str;
}
function KindClearAttributeScriptTag(str)
{
	var re = new RegExp("(\\son[a-z]+=)[\"']?[^>]*?[^\\\\\>][\"']?([\\s>])","ig");
	str = str.replace(re, function ($0,$1,$2) {
						return($1.toLowerCase() + "\"\"" + $2);
					}
				);
	return str;
}
function KindClearScriptTag(str)
{
	if (KE_SAFE_MODE == false) {
		return str;
	}
	str = str.replace(/<(script.*?)>/gi, "[$1]");
	str = str.replace(/<\/script>/gi, "[/script]");
	return str;
}
function KindHtmlentities(str)
{
	str = str.replace(/&/g,'&amp;');
	str = str.replace(/</g,'&lt;');
	str = str.replace(/>/g,'&gt;');
	str = str.replace(/"/g,'&quot;');
	return str;
}
function KindGetTop(id)
{
	var top = 28;
	var tmp = '';
	var obj = document.getElementById(id);
	while (eval("obj" + tmp).tagName != "BODY") {
		tmp += ".offsetParent";
		top += eval("obj" + tmp).offsetTop;
	}
	return top;
}
function KindGetLeft(id)
{
	var left = 2;
	var tmp = '';
	var obj = document.getElementById(id);
	while (eval("obj" + tmp).tagName != "BODY") {
		tmp += ".offsetParent";
		left += eval("obj" + tmp).offsetLeft;
	}
	return left;
}
function KindDisplayMenu(cmd)
{
	KindEditorForm.focus();
	if (cmd != 'KE_ABOUT') {
		KindSelection();
	}
	KindDisableMenu();
	var top, left;
	top = KindGetTop(cmd);
	left = KindGetLeft(cmd);
	if (cmd == 'KE_ABOUT') {
		left -= 200;
	} else if (cmd == 'KE_LINK') {
		left -= 220;
	}
	document.getElementById('POPUP_'+cmd).style.top =  top.toString(10) + 'px';
	document.getElementById('POPUP_'+cmd).style.left = left.toString(10) + 'px';
	document.getElementById('POPUP_'+cmd).style.display = 'block';
}
function KindDisableMenu()
{
	for (i = 0; i < KE_POPUP_MENU_TABLE.length; i++) {
		document.getElementById('POPUP_'+KE_POPUP_MENU_TABLE[i]).style.display = 'none';
	}
}
function KindReloadIframe()
{
	var str = '';
	str += KindPopupMenu('KE_IMAGE');
	str += KindPopupMenu('KE_FLV');
	str += KindPopupMenu('KE_MYFILES');
	str += KindPopupMenu('KE_FLASH');
	str += KindPopupMenu('KE_MEDIA');
	str += KindPopupMenu('KE_REAL');
	//document.getElementById('InsertIframe').innerHTML = str;
	KindDrawIframe('KE_IMAGE');
	KindDrawIframe('KE_FLV');
	KindDrawIframe('KE_MYFILES');
	KindDrawIframe('KE_FLASH');
	KindDrawIframe('KE_MEDIA');
	KindDrawIframe('KE_REAL');
}

/*
function KindGetMenuCommonStyle()
{
	var str = 'position:absolute;top:1px;left:1px;font-size:12px;color:'+KE_MENU_TEXT_COLOR+
			';background-color:'+KE_MENU_BG_COLOR+';border:solid 1px '+KE_MENU_BORDER_COLOR+';z-index:1;display:none;';
	return str;
}


function KindGetCommonMenu(cmd, content)
{
	var str = '';
	str += '<div id="POPUP_'+cmd+'" style="'+KindGetMenuCommonStyle()+'">';
	str += content;
	str += '</div>';
	return str;
}

function KindCreateColorTable(cmd, eventStr)
{
	var str = '';
	str += '<table cellpadding="0" cellspacing="2" border="0">';
	for (i = 0; i < KE_COLOR_TABLE.length; i++) {
		if (i == 0 || (i >= 10 && i%10 == 0)) {
			str += '<tr>';
		}
		str += '<td style="width:12px;height:12px;border:1px solid #AAAAAA;font-size:1px;cursor:pointer;background-color:' +
		KE_COLOR_TABLE[i] + ';" onmouseover="javascript:this.style.borderColor=\'#000000\';' + ((eventStr) ? eventStr : '') + '" ' +
		'onmouseout="javascript:this.style.borderColor=\'#AAAAAA\';" ' + 
		'onclick="javascript:KindExecute(\''+cmd+'_END\', \'' + KE_COLOR_TABLE[i] + '\');">&nbsp;</td>';
		if (i >= 9 && i%(i-1) == 0) {
			str += '</tr>';
		}
	}
	str += '</table>';
	return str;
}

function KindDrawColorTable(cmd)
{
	var str = '';
	str += '<div id="POPUP_'+cmd+'" style="width:160px;padding:2px;'+KindGetMenuCommonStyle()+'">';
	str += KindCreateColorTable(cmd);
	str += '</div>';
	return str;
}
*/
function KindDrawMedia(cmd)
{
	var str = '';
	str += '<div align="center">' +
			'<form name="uploadForm" id="uploadForm" style="margin:0;padding:0;" method="post" enctype="multipart/form-data" ' +
			'action="' + KE_IMAGE_UPLOAD_CGI + '" onsubmit="javascript:if(parent.KindDrawImageP8FLVEnd(\''+cmd+'\')==false){return false;};">' +
			'<input type="hidden" name="fileName" id="fileName" value="" />' + 
			'<table cellpadding="0" cellspacing="0" style="width:100%;font-size:12px;">' + 
			'<tr><td colspan="2"></td></tr>' +  	
			'<tr><td style="width:50px;padding-left:5px;">';
	if (KE_UPLOAD_MODE == true) {
			str += '<select id="imageType" onchange="javascript:parent.KindImageP8FLVType(this.value,\''+cmd+'\');document.getElementById(\''+cmd+'submitButton\').focus();"><option value="1" selected="selected">'+KE_LANG['LOCAL']+'</option><option value="2">'+KE_LANG['REMOTE']+'</option></select>';
	} else {
			str += KE_LANG['REMOTE'];
	}
	str += '</td><td style="width:200px;padding-bottom:3px;">';
	if (KE_UPLOAD_MODE == true) {
			str += '<input type="text" id="imgLink" value="http://" maxlength="255" style="width:95%;border:1px solid #555555;display:none;" />' +
			'<input type="file" name="fileData" id="imgFile" size="14" style="border:1px solid #555555;" onclick="javascript:document.getElementById(\'imgLink\').value=\'http://\';" />';
	} else {
			str += '<input type="text" id="imgLink" value="http://" maxlength="255" style="width:95%;border:1px solid #555555;" />' +
			'<input type="hidden" name="imageType" id="imageType" value="2"><input type="hidden" name="fileData" id="imgFile" value="" />';
	}
	str += '</td></tr><tr><td colspan="2" style="padding-bottom:3px;">' +	
			'<table border="0" style="width:100%;font-size:12px;"><tr>' +
			'<td width="10%" style="padding:2px 2px 2px 5px;">'+KE_LANG['WIDTH']+'</td><td width="23%"><input type="text" name="imgWidth" id="imgWidth" value="0" maxlength="4" style="width:40px;border:1px solid #555555;" /></td>' +
			'<td width="10%" style="padding:2px;">'+KE_LANG['HEIGHT']+'</td><td width="23%"><input type="text" name="imgHeight" id="imgHeight" value="0" maxlength="4" style="width:40px;border:1px solid #555555;" /></td>' +
			'</tr></table>' +
			'</td></tr><tr><td colspan="2" style="margin:5px;padding-bottom:5px;" align="center">' +
			'<input type="submit" name="button" id="'+cmd+'submitButton" value="'+KE_LANG['CONFIRM']+'" style="border:1px solid #555555;background-color:'+KE_BUTTON_COLOR+';" /> ' +
			'<input type="button" name="button" value="'+KE_LANG['CANCEL']+'" onclick="javascript:parent.KindDisableMenu();parent.KindReloadIframe();" style="border:1px solid #555555;background-color:'+KE_BUTTON_COLOR+';" /></td></tr>' + 
			'</table></form></div>';
	return str;
}
function KindPopupMenu(cmd)
{
	switch (cmd)
	{
		case 'KE_ZOOM':
			
			return KE_ZOOM_str;
			break;
		case 'KE_TITLE':
			
			return KE_TITLE_str;
			break;
		case 'KE_FONTNAME':
			
			return KE_FONTNAME_str;
			break;
		case 'KE_FONTSIZE':
			
			return KE_FONTSIZE_str;
			break;
		case 'KE_TEXTCOLOR':
			
			return KE_TEXTCOLOR_str;
			break;
		case 'KE_BGCOLOR':
			
			return KE_BGCOLOR_str;
			break;
		case 'KE_HR':
			
			return KE_HR_str;
			break;
		case 'KE_LAYER':
			
			return KE_LAYER_str;
			break;
		case 'KE_ICON':
			
			return KE_ICON_str;
			break;
		case 'KE_SPECIALCHAR':
			
			return KE_SPECIALCHAR_str;
			break;
		case 'KE_TABLE':
			
			return KE_TABLE_str;
			break;
		case 'KE_IMAGE':
			
			return KE_IMAGE_str;
			break;
		case 'KE_FLV':

			return KE_FLV_str;
			break;
		case 'KE_MYFILES':

			return KE_MYFILES_str;
			break;
		case 'KE_FLASH':
			
			return KE_FLASH_str;
			break;
		case 'KE_MEDIA':
			
			return KE_MEDIA_str;
			break;
		case 'KE_REAL':
			
			return KE_REAL_str;
			break;
		case 'KE_LINK':
			
			return KE_LINK_str;
			break;
		case 'KE_ABOUT':
			
			return KE_ABOUT_str;
			break;
		default: 
			break;
	}
}
function KindDrawIframe(cmd)
{
	if (KE_BROWSER == 'IE') {
		
		KE_IMAGE_DOCUMENT = document.frames("KindImageIframe").document;
		KE_FLV_DOCUMENT = document.frames("KindImageP8FLVIframe").document;
		KE_MYFILES_DOCUMENT = document.frames("KindImageP8MYFILESIframe").document;
		KE_FLASH_DOCUMENT = document.frames("KindFlashIframe").document;
		KE_MEDIA_DOCUMENT = document.frames("KindMediaIframe").document;
		KE_REAL_DOCUMENT = document.frames("KindRealIframe").document;
		KE_LINK_DOCUMENT = document.frames("KindLinkIframe").document;
	} else {
		
		KE_IMAGE_DOCUMENT = document.getElementById('KindImageIframe').contentDocument;
		KE_FLV_DOCUMENT = document.getElementById('KindImageP8FLVIframe').contentDocument;
		KE_MYFILES_DOCUMENT = document.getElementById('KindImageP8MYFILESIframe').contentDocument;
		KE_FLASH_DOCUMENT = document.getElementById('KindFlashIframe').contentDocument;
		KE_MEDIA_DOCUMENT = document.getElementById('KindMediaIframe').contentDocument;
		KE_REAL_DOCUMENT = document.getElementById('KindRealIframe').contentDocument;
		KE_LINK_DOCUMENT = document.getElementById('KindLinkIframe').contentDocument;
	}
	switch (cmd)
	{
		case 'KE_IMAGE':
			var str = '';
			str += '<div align="center">' +
				'<form name="uploadForm" style="margin:0;padding:0;" method="post" enctype="multipart/form-data" ' +
				'action="' + KE_IMAGE_UPLOAD_CGI + '" onsubmit="javascript:if(parent.KindDrawImageEnd()==false){return false;};">' +
				'<input type="hidden" name="fileName" id="fileName" value="" />' + 
				'<table cellpadding="0" cellspacing="0" style="width:100%;font-size:12px;">' + 
				'<tr><td colspan="2"><table border="0" style="margin-bottom:3px;display:none;"><tr><td id="imgPreview" style="width:240px;height:240px;border:1px solid #AAAAAA;background-color:#FFFFFF;" align="center" valign="middle">&nbsp;</td></tr></table></td></tr>' +  	
				'<tr><td style="width:50px;padding-left:5px;">';
			if (KE_UPLOAD_MODE == true) {
				str += '<select id="imageType" onchange="javascript:parent.KindImageType(this.value);document.getElementById(\''+cmd+'submitButton\').focus();"><option value="1" selected="selected">'+KE_LANG['LOCAL']+'</option><option value="2">'+KE_LANG['REMOTE']+'</option></select>';
			} else {
				str += KE_LANG['REMOTE'];
			}
			str += '</td><td style="width:200px;padding-bottom:3px;">';
			if (KE_UPLOAD_MODE == true) {
				str += '<input type="text" id="imgLink" value="http://" maxlength="255" style="width:95%;border:1px solid #555555;display:none;" />' +
				'<input type="file" name="fileData" id="imgFile" size="14" style="border:1px solid #555555;" onclick="javascript:document.getElementById(\'imgLink\').value=\'http://\';" />';
			} else {
				str += '<input type="text" id="imgLink" value="http://" maxlength="255" style="width:95%;border:1px solid #555555;" />' +
				'<input type="hidden" name="imageType" id="imageType" value="2"><input type="hidden" name="fileData" id="imgFile" value="" />';
			}
			str += '</td></tr><tr><td colspan="2" style="padding-bottom:3px;">' +
				'<table border="0" style="width:100%;font-size:12px;"><tr>' +
				'<td width="18%" style="padding:2px 2px 2px 5px;">'+KE_LANG['TITLE']+'</td><td width="82%"><input type="text" name="imgTitle" id="imgTitle" value="" maxlength="100" style="width:95%;border:1px solid #555555;" /></td></tr></table>' +	
				'<table border="0" style="width:100%;font-size:12px;"><tr>' +
				'<td width="10%" style="padding:2px 2px 2px 5px;">'+KE_LANG['WIDTH']+'</td><td width="23%"><input type="text" name="imgWidth" id="imgWidth" value="0" maxlength="4" style="width:40px;border:1px solid #555555;" /></td>' +
				'<td width="10%" style="padding:2px;">'+KE_LANG['HEIGHT']+'</td><td width="23%"><input type="text" name="imgHeight" id="imgHeight" value="0" maxlength="4" style="width:40px;border:1px solid #555555;" /></td>' +
				'<td width="10%" style="padding:2px;">'+KE_LANG['BORDER']+'</td><td width="23%"><input type="text" name="imgBorder" id="imgBorder" value="0" maxlength="1" style="width:20px;border:1px solid #555555;" /></td></tr></table>' +
				'<table border="0" style="width:100%;font-size:12px;"><tr>' +
				'<td width="39%" style="padding:2px 2px 2px 5px;"><select id="imgAlign" name="imgAlign"><option value="">'+KE_LANG['ALIGN']+'</option>';
			for (var i = 0; i < KE_IMAGE_ALIGN_TABLE.length; i++) {
				str += '<option value="' + KE_IMAGE_ALIGN_TABLE[i] + '">' + KE_IMAGE_ALIGN_TABLE[i] + '</option>';
			}
			str += '</select></td>' +
				'<td width="15%" style="padding:2px;">'+KE_LANG['HSPACE']+'</td><td width="15%"><input type="text" name="imgHspace" id="imgHspace" value="0" maxlength="1" style="width:20px;border:1px solid #555555;" /></td>' +
				'<td width="15%" style="padding:2px;">'+KE_LANG['VSPACE']+'</td><td width="15%"><input type="text" name="imgVspace" id="imgVspace" value="0" maxlength="1" style="width:20px;border:1px solid #555555;" /></td></tr></table>' +
				'</td></tr><tr><td colspan="2" style="margin:5px;padding-bottom:5px;" align="center">' +
				'<input type="submit" name="button" id="'+cmd+'submitButton" value="'+KE_LANG['CONFIRM']+'" style="border:1px solid #555555;background-color:'+KE_BUTTON_COLOR+';" /> ' +
				'<input type="button" name="button" value="'+KE_LANG['CANCEL']+'" onclick="javascript:parent.KindDisableMenu();parent.KindReloadIframe();" style="border:1px solid #555555;background-color:'+KE_BUTTON_COLOR+';" /></td></tr>' + 
				'</table></form></div>';
			KindDrawMenuIframe(KE_IMAGE_DOCUMENT, str);
			break;
		case 'KE_FLV':
			var str = KindDrawMedia(cmd);
			KindDrawMenuIframe(KE_FLV_DOCUMENT, str);
			break;
		case 'KE_MYFILES':
			var str = KindDrawMedia(cmd);
			KindDrawMenuIframe(KE_MYFILES_DOCUMENT, str);
			break;
		case 'KE_FLASH':
			var str = KindDrawMedia(cmd);
			KindDrawMenuIframe(KE_FLASH_DOCUMENT, str);
			break;
		case 'KE_MEDIA':
			var str = KindDrawMedia(cmd);
			KindDrawMenuIframe(KE_MEDIA_DOCUMENT, str);
			break;
		case 'KE_REAL':
			var str = KindDrawMedia(cmd);
			KindDrawMenuIframe(KE_REAL_DOCUMENT, str);
			break;
		case 'KE_LINK':
			var str = '';
			str += '<table cellpadding="0" cellspacing="0" style="width:100%;font-size:12px;">' + 
				'<tr><td style="width:50px;padding:5px;">URL</td>' +
				'<td style="width:200px;padding-top:5px;padding-bottom:5px;"><input type="text" id="hyperLink" value="http://" style="width:190px;border:1px solid #555555;background-color:#FFFFFF;"></td>' +
				'<tr><td style="padding:5px;">'+KE_LANG['TARGET']+'</td>' +
				'<td style="padding-bottom:5px;"><select id="hyperLinkTarget"><option value="_blank" selected="selected">'+KE_LANG['NEW_WINDOW']+'</option><option value="">'+KE_LANG['CURRENT_WINDOW']+'</option></select></td></tr>' + 
				'<tr><td colspan="2" style="padding-bottom:5px;" align="center">' +
				'<input type="submit" name="button" id="'+cmd+'submitButton" value="'+KE_LANG['CONFIRM']+'" onclick="javascript:parent.KindDrawLinkEnd();" style="border:1px solid #555555;background-color:'+KE_BUTTON_COLOR+';" /> ' +
				'<input type="button" name="button" value="'+KE_LANG['CANCEL']+'" onclick="javascript:parent.KindDisableMenu();" style="border:1px solid #555555;background-color:'+KE_BUTTON_COLOR+';" /></td></tr>';
			str += '</table>';
			KindDrawMenuIframe(KE_LINK_DOCUMENT, str);
			break;
		default:
			break;
	}
}
function KindDrawMenuIframe(obj, str)
{
	obj.open();
	obj.write(str);
	obj.close();
	obj.body.style.color = KE_MENU_TEXT_COLOR;
	obj.body.style.backgroundColor = KE_MENU_BG_COLOR;
	obj.body.style.margin = 0;
	obj.body.scroll = 'no';
}
function KindDrawTableSelected(i, j)
{
	var text = i.toString(10) + ' by ' + j.toString(10) + ' Table';
	document.getElementById('tableLocation').innerHTML = text;
	var num = 10;
	for (m = 1; m <= num; m++) {
		for (n = 1; n <= num; n++) {
			var obj = document.getElementById('kindTableTd' + m.toString(10) + '_' + n.toString(10) + '');
			if (m <= i && n <= j) {
				obj.style.backgroundColor = KE_MENU_SELECTED_COLOR;
			} else {
				obj.style.backgroundColor = '#FFFFFF';
			}
		}
	}
}
function KindImageType(type)
{
	if (type == 1) {
		KE_IMAGE_DOCUMENT.getElementById('imgFile').style.display = 'block';
		KE_IMAGE_DOCUMENT.getElementById('imgLink').style.display = 'none';
		KE_IMAGE_DOCUMENT.getElementById('imgLink').value = 'http://';
	} else {
		KE_IMAGE_DOCUMENT.getElementById('imgFile').style.display = 'none';
		KE_IMAGE_DOCUMENT.getElementById('imgLink').style.display = 'block';
	}
	KE_IMAGE_DOCUMENT.getElementById('imgPreview').innerHTML = "&nbsp;";
	KE_IMAGE_DOCUMENT.getElementById('imgWidth').value = 0;
	KE_IMAGE_DOCUMENT.getElementById('imgHeight').value = 0;
}


function KindImageP8FLVType(type,P8TYPE)
{
	if(P8TYPE=='KE_FLV'){
		OBJ=KE_FLV_DOCUMENT;
	}else if(P8TYPE=='KE_FLASH'){
		OBJ=KE_FLASH_DOCUMENT;
	}else if(P8TYPE=='KE_MEDIA'){
		OBJ=KE_MEDIA_DOCUMENT;
	}else if(P8TYPE=='KE_REAL'){
		OBJ=KE_REAL_DOCUMENT;
	}else if(P8TYPE=='KE_MYFILES'){
		OBJ=KE_MYFILES_DOCUMENT;
	}else{
		return ;
	}
	
	if (type == 1) {
		OBJ.getElementById('imgFile').style.display = 'block';
		OBJ.getElementById('imgLink').style.display = 'none';
		OBJ.getElementById('imgLink').value = 'http://';
	} else {
		OBJ.getElementById('imgFile').style.display = 'none';
		OBJ.getElementById('imgLink').style.display = 'block';
	}
	OBJ.getElementById('imgWidth').value = 0;
	OBJ.getElementById('imgHeight').value = 0;
}
function KindImagePreview()
{
	var type = KE_IMAGE_DOCUMENT.getElementById('imageType').value;
	var url = KE_IMAGE_DOCUMENT.getElementById('imgLink').value;
	var file = KE_IMAGE_DOCUMENT.getElementById('imgFile').value;
	if (type == 1) {
		if (KE_BROWSER != 'IE') {
			return false;
		}
		if (file == '') {
			alert(KE_LANG['SELECT_IMAGE']);
			return false;
		}
		url = 'file:///' + file;
		if (KindCheckImageFileType(url, "\\") == false) {
			return false;
		}
	} else {
		if (KindCheckImageFileType(url, "/") == false) {
			return false;
		}
	}
	var imgObj = KE_IMAGE_DOCUMENT.createElement("IMG");
	imgObj.src = url;
	var width = parseInt(imgObj.width);
	var height = parseInt(imgObj.height);
	KE_IMAGE_DOCUMENT.getElementById('imgWidth').value = width;
	KE_IMAGE_DOCUMENT.getElementById('imgHeight').value = height;
	var rate = parseInt(width/height);
	if (width >230 && height <= 230) {
		width = 230;
		height = parseInt(width/rate);
	} else if (width <=230 && height > 230) {
		height = 230;
		width = parseInt(height*rate);
	} else if (width >230 && height > 230) {
		if (width >= height) {
			width = 230;
			height = parseInt(width/rate);
		} else {
			height = 230;
			width = parseInt(height*rate);
		}
	}
	imgObj.style.width = width;
	imgObj.style.height = height;
	var el = KE_IMAGE_DOCUMENT.getElementById('imgPreview');
	if (el.hasChildNodes()) {
		el.removeChild(el.childNodes[0]);
	}
	el.appendChild(imgObj);
	return imgObj;
}
function KindDrawImageP8FLVEnd(cmd)
{
	if(cmd=='KE_FLV'){
		OBJ=KE_FLV_DOCUMENT;
	}else if(cmd=='KE_FLASH'){
		OBJ=KE_FLASH_DOCUMENT;
	}else if(cmd=='KE_MEDIA'){
		OBJ=KE_MEDIA_DOCUMENT;
	}else if(cmd=='KE_REAL'){
		OBJ=KE_REAL_DOCUMENT;
	}else if(cmd=='KE_MYFILES'){
		OBJ=KE_MYFILES_DOCUMENT;
	}else{
		return ;
	}
	var type = OBJ.getElementById('imageType').value;
	var url = OBJ.getElementById('imgLink').value;
	var file = OBJ.getElementById('imgFile').value;
	var width = OBJ.getElementById('imgWidth').value;
	var height = OBJ.getElementById('imgHeight').value;
	if (type == 1) {
		if (file == '') {
			alert(KE_LANG['SELECT_IMAGE']);
			return false;
		}
		if (KindCheckImageP8FLVFileType(file, "\\",cmd) == false) {
			return false;
		}
	} else {
		if (KindCheckImageP8FLVFileType(url, "/",cmd) == false) {
			return false;
		}
	}
	if (width.match(/^\d+$/) == null) {
		alert(KE_LANG['INVALID_WIDTH']);
		return false;
	}
	if (height.match(/^\d+$/) == null) {
		alert(KE_LANG['INVALID_HEIGHT']);
		return false;
	}
	var fileName;
	KindEditorForm.focus();
	if (type == 1) {
		fileName = KindGetFileName(file, "\\");
		var fileExt = KindGetFileExt(fileName);
		var dateObj = new Date();
		var year = dateObj.getFullYear().toString(10);
		var month = (dateObj.getMonth() + 1).toString(10);
		month = month.length < 2 ? '0' + month : month;
		var day = dateObj.getDate().toString(10);
		day = day.length < 2 ? '0' + day : day;
		var ymd = year + month + day;
		fileName = ymd + dateObj.getTime().toString(10) + '.' + fileExt;
		OBJ.getElementById('fileName').value = fileName;
		OBJ.getElementById('uploadForm').action+="?Ctype="+cmd;
	} else {
		KindInsertImageP8FLV(url, width, height, cmd);
	}
}
function KindDrawImageEnd()
{
	var type = KE_IMAGE_DOCUMENT.getElementById('imageType').value;
	var url = KE_IMAGE_DOCUMENT.getElementById('imgLink').value;
	var file = KE_IMAGE_DOCUMENT.getElementById('imgFile').value;
	var width = KE_IMAGE_DOCUMENT.getElementById('imgWidth').value;
	var height = KE_IMAGE_DOCUMENT.getElementById('imgHeight').value;
	var border = KE_IMAGE_DOCUMENT.getElementById('imgBorder').value;
	var title = KE_IMAGE_DOCUMENT.getElementById('imgTitle').value;
	var align = KE_IMAGE_DOCUMENT.getElementById('imgAlign').value;
	var hspace = KE_IMAGE_DOCUMENT.getElementById('imgHspace').value;
	var vspace = KE_IMAGE_DOCUMENT.getElementById('imgVspace').value;
	if (type == 1) {
		if (file == '') {
			alert(KE_LANG['SELECT_IMAGE']);
			return false;
		}
		if (KindCheckImageFileType(file, "\\") == false) {
			return false;
		}
	} else {
		if (KindCheckImageFileType(url, "/") == false) {
			return false;
		}
	}
	if (width.match(/^\d+$/) == null) {
		alert(KE_LANG['INVALID_WIDTH']);
		return false;
	}
	if (height.match(/^\d+$/) == null) {
		alert(KE_LANG['INVALID_HEIGHT']);
		return false;
	}
	if (border.match(/^\d+$/) == null) {
		alert(KE_LANG['INVALID_BORDER']);
		return false;
	}
	if (hspace.match(/^\d+$/) == null) {
		alert(KE_LANG['INVALID_HSPACE']);
		return false;
	}
	if (vspace.match(/^\d+$/) == null) {
		alert(KE_LANG['INVALID_VSPACE']);
		return false;
	}
	var fileName;
	KindEditorForm.focus();
	if (type == 1) {
		fileName = KindGetFileName(file, "\\");
		var fileExt = KindGetFileExt(fileName);
		var dateObj = new Date();
		var year = dateObj.getFullYear().toString(10);
		var month = (dateObj.getMonth() + 1).toString(10);
		month = month.length < 2 ? '0' + month : month;
		var day = dateObj.getDate().toString(10);
		day = day.length < 2 ? '0' + day : day;
		var ymd = year + month + day;
		fileName = ymd + dateObj.getTime().toString(10) + '.' + fileExt;
		KE_IMAGE_DOCUMENT.getElementById('fileName').value = fileName;
	} else {
		KindInsertImage(url, width, height, border, title, align, hspace, vspace);
	}
}
function KindInsertImageP8FLV(url, width, height, cmd)
{
	KindSelect();
	var element = document.createElement("div");
	if(width=='0'){
		width=400;
	}
	if(height=='0'){
		height=300;
	}
	if(cmd=='KE_FLV'){
		str=" <embed type='application/x-shockwave-flash' src='/images/default/player.swf?vcastr_file="+url+"&IsAutoPlay=true' width='"+width+"' height='"+height+"' allowFullScreen='true'></embed>";
	}else if(cmd=='KE_FLASH'){
		str=" <embed type='application/x-shockwave-flash' src='"+url+"' width='"+width+"' height='"+height+"'></embed>";
	}else if(cmd=='KE_MEDIA'){
		height=parseInt(height)+30;
		str="<embed src='"+url+"' type='video/x-ms-asf-plugin' quality='high' ShowStatusBar='true' style='width:"+width+"px;height:"+height+"px;'></embed>";
	}else if(cmd=='KE_REAL'){
		str="<embed SRC='"+url+"' type='audio/x-pn-realaudio-plugin' CONSOLE='Clip1' CONTROLS='ImageWindow' WIDTH='"+width+"' HEIGHT='"+height+"' AUTOSTART='true'></embed><br><embed type='audio/x-pn-realaudio-plugin' CONSOLE='Clip1' CONTROLS='ControlPanel,StatusBar' WIDTH='"+width+"' HEIGHT='50' AUTOSTART='true'></embed>";
	}else if(cmd=='KE_MYFILES'){
		str="<a style=\"COLOR: red\" href='"+url+"' target=_blank p8name=\"p8download\">�������</a>";
	}else{
		str='take a test';
	}

	element.innerHTML = str;
	KindInsertItem(element);
	KindDisableMenu();
	KindReloadIframe();
}
function KindInsertImage(url, width, height, border, title, align, hspace, vspace)
{
	var element = document.createElement("img");
	element.src = url;
	if (width > 0) {
		element.style.width = width;
	}
	if (height > 0) {
		element.style.height = height;
	}
	if (align != "") {
		element.align = align;
	}
	if (hspace > 0) {
		element.hspace = hspace;
	}
	if (vspace > 0) {
		element.vspace = vspace;
	}
	element.border = border;
	element.alt = KindHtmlentities(title);
	KindSelect();
	KindInsertItem(element);
	KindDisableMenu();
	KindReloadIframe();
}

/*
function KindGetFlashHtmlTag(url)
{
	var str = '<embed src="'+url+'" type="application/x-shockwave-flash" quality="high"></embed>';
	return str;
}
function KindFlashPreview()
{
	var url = KE_FLASH_DOCUMENT.getElementById('flashLink').value;
	if (KindCheckFlashFileType(url, "/") == false) {
		return false;
	}
	var el = KE_FLASH_DOCUMENT.getElementById('flashPreview');
	el.innerHTML = KindGetFlashHtmlTag(url);
}

function KindDrawFlashEnd()
{
	var url = KE_FLASH_DOCUMENT.getElementById('flashLink').value;
	if (KindCheckFlashFileType(url, "/") == false) {
		return false;
	}
	KindEditorForm.focus();
	KindSelect();
	var obj = document.createElement("EMBED");
	obj.src = url;
	obj.type = "application/x-shockwave-flash";
	obj.quality = "high";
	KindInsertItem(obj);
	KindDisableMenu();
}

function KindGetMediaHtmlTag(cmd, url)
{
	var str = '<embed src="'+url+'" type="';
	if (cmd == "KE_REAL") {
		str += 'audio/x-pn-realaudio-plugin';
	} else {
		str += 'video/x-ms-asf-plugin';
	}
	str += '" width="230" height="230" loop="true" autostart="true">';
	return str;
}
function KindMediaPreview(cmd)
{
	var mediaDocument;
	if (cmd == 'KE_REAL') {
		mediaDocument = KE_REAL_DOCUMENT;
	} else {
		mediaDocument = KE_MEDIA_DOCUMENT;
	}
	var url = mediaDocument.getElementById(cmd+'link').value;
	if (KindCheckMediaFileType(cmd, url, "/") == false) {
		return false;
	}
	var el = mediaDocument.getElementById(cmd+'preview');
	el.innerHTML = KindGetMediaHtmlTag(cmd, url);
}

function KindDrawMediaEnd(cmd)
{
	var mediaDocument;
	if (cmd == 'KE_REAL') {
		mediaDocument = KE_REAL_DOCUMENT;
	} else {
		mediaDocument = KE_MEDIA_DOCUMENT;
	}
	var url = mediaDocument.getElementById(cmd+'link').value;
	if (KindCheckMediaFileType(cmd, url, "/") == false) {
		return false;
	}
	KindEditorForm.focus();
	KindSelect();
	var obj = document.createElement("EMBED");
	obj.src = url;
	if (cmd == 'KE_REAL') {
		obj.type = 'audio/x-pn-realaudio-plugin';
	} else {
		obj.type = 'video/x-ms-asf-plugin';
	}
	obj.loop = 'true';
	obj.autostart = 'true';
	KindInsertItem(obj);
	KindDisableMenu(cmd);
}
*/
function KindDrawLinkEnd()
{
	var range;
	var url = KE_LINK_DOCUMENT.getElementById('hyperLink').value;
	var target = KE_LINK_DOCUMENT.getElementById('hyperLinkTarget').value;
	if (url.match(/http:\/\/.{3,}/) == null) {
		alert(KE_LANG['INPUT_URL']);
		return false;
	}
	KindEditorForm.focus();
	KindSelect();
	var element;
    if (KE_BROWSER == 'IE') {
		if (KE_SELECTION.type.toLowerCase() == 'control') {
			var el = document.createElement("a");
			el.href = url;
			if (target) {
				el.target = target;
			}
			KE_RANGE.item(0).applyElement(el);
		} else if (KE_SELECTION.type.toLowerCase() == 'text') {
			KindExecuteValue('CreateLink', url);
			element = KE_RANGE.parentElement();
			if (target) {
				element.target = target;
			}
		}
	} else {
		KindExecuteValue('CreateLink', url);
		element = KE_RANGE.startContainer.previousSibling;
		element.target = target;
		if (target) {
			element.target = target;
		}
    }
	KindDisableMenu();
}
function KindSelection()
{
	if (KE_BROWSER == 'IE') {
		KE_SELECTION = KE_EDITFORM_DOCUMENT.selection;
		KE_RANGE = KE_SELECTION.createRange();
		KE_RANGE_TEXT = KE_RANGE.text;
	} else {
		KE_SELECTION = document.getElementById("KindEditorForm").contentWindow.getSelection();
        KE_RANGE = KE_SELECTION.getRangeAt(0);
		KE_RANGE_TEXT = KE_RANGE.toString();
	}
}
function KindSelect()
{
	if (KE_BROWSER == 'IE') {
		KE_RANGE.select();
	}
}
function KindInsertItem(insertNode)
{
	if (KE_BROWSER == 'IE') {
		if (KE_SELECTION.type.toLowerCase() == 'control') {
			KE_RANGE.item(0).outerHTML = insertNode.outerHTML;
		} else {
			KE_RANGE.pasteHTML(insertNode.outerHTML);
		}
	} else {
        KE_SELECTION.removeAllRanges();
		KE_RANGE.deleteContents();
        var startRangeNode = KE_RANGE.startContainer;
        var startRangeOffset = KE_RANGE.startOffset;
        var newRange = document.createRange();
		if (startRangeNode.nodeType == 3 && insertNode.nodeType == 3) {
            startRangeNode.insertData(startRangeOffset, insertNode.nodeValue);
            newRange.setEnd(startRangeNode, startRangeOffset + insertNode.length);
            newRange.setStart(startRangeNode, startRangeOffset + insertNode.length);
        } else {
            var afterNode;
            if (startRangeNode.nodeType == 3) {
                var textNode = startRangeNode;
                startRangeNode = textNode.parentNode;
                var text = textNode.nodeValue;
                var textBefore = text.substr(0, startRangeOffset);
                var textAfter = text.substr(startRangeOffset);
                var beforeNode = document.createTextNode(textBefore);
                var afterNode = document.createTextNode(textAfter);
                startRangeNode.insertBefore(afterNode, textNode);
                startRangeNode.insertBefore(insertNode, afterNode);
                startRangeNode.insertBefore(beforeNode, insertNode);
                startRangeNode.removeChild(textNode);
            } else {
				if (startRangeNode.tagName.toLowerCase() == 'html') {
					startRangeNode = startRangeNode.childNodes[0].nextSibling;
					afterNode = startRangeNode.childNodes[0];
				} else {
					afterNode = startRangeNode.childNodes[startRangeOffset];
				}
				startRangeNode.insertBefore(insertNode, afterNode);
            }
            newRange.setEnd(afterNode, 0);
            newRange.setStart(afterNode, 0);
        }
        KE_SELECTION.addRange(newRange);
	}
}
function KindExecuteValue(cmd, value)
{
	KE_EDITFORM_DOCUMENT.execCommand(cmd, false, value);
}
function KindSimpleExecute(cmd)
{
	KindEditorForm.focus();
	KE_EDITFORM_DOCUMENT.execCommand(cmd, false, null);
	KindDisableMenu();
}
function KindExecute(cmd, value)
{
	switch (cmd)
	{
		case 'KE_SOURCE':
			var length = document.getElementById(KE_TOP_TOOLBAR_ICON[0][0]).src.length - 10;
			var image = document.getElementById(KE_TOP_TOOLBAR_ICON[0][0]).src.substr(length,10);
			if (image == 'source.gif') {
				document.getElementById("KindCodeForm").value = KindHtmlToXhtml(KE_EDITFORM_DOCUMENT.body.innerHTML);
				document.getElementById("KindEditorIframe").style.display = 'none';
				document.getElementById("KindEditTextarea").style.display = 'block';
				KindDisableToolbar(true);
			} else {
				KE_EDITFORM_DOCUMENT.body.innerHTML = KindClearScriptTag(document.getElementById("KindCodeForm").value);
				document.getElementById("KindEditTextarea").style.display = 'none';
				document.getElementById("KindEditorIframe").style.display = 'block';
				KindDisableToolbar(false);
			}
			KindDisableMenu();
			break;
		case 'KE_PRINT':
			KindSimpleExecute('print');
			break;
		case 'KE_UNDO':
			KindSimpleExecute('undo');
			break;
		case 'KE_REDO':
			KindSimpleExecute('redo');
			break;
		case 'KE_CUT':
			KindSimpleExecute('cut');
			break;
		case 'KE_COPY':
			KindSimpleExecute('copy');
			break;
		case 'KE_PASTE':
			KindSimpleExecute('paste');
			break;
		case 'KE_SELECTALL':
			KindSimpleExecute('selectall');
			break;
		case 'KE_SUBSCRIPT':
			KindSimpleExecute('subscript');
			break;
		case 'KE_SUPERSCRIPT':
			KindSimpleExecute('superscript');
			break;
		case 'KE_BOLD':
			KindSimpleExecute('bold');
			break;
		case 'KE_ITALIC':
			KindSimpleExecute('italic');
			break;
		case 'KE_UNDERLINE':
			KindSimpleExecute('underline');
			break;
		case 'KE_STRIKE':
			KindSimpleExecute('strikethrough');
			break;
		case 'KE_JUSTIFYLEFT':
			KindSimpleExecute('justifyleft');
			break;
		case 'KE_JUSTIFYCENTER':
			KindSimpleExecute('justifycenter');
			break;
		case 'KE_JUSTIFYRIGHT':
			KindSimpleExecute('justifyright');
			break;
		case 'KE_JUSTIFYFULL':
			KindSimpleExecute('justifyfull');
			break;
		case 'KE_NUMBEREDLIST':
			KindSimpleExecute('insertorderedlist');
			break;
		case 'KE_UNORDERLIST':
			KindSimpleExecute('insertunorderedlist');
			break;
		case 'KE_INDENT':
			KindSimpleExecute('indent');
			break;
		case 'KE_OUTDENT':
			KindSimpleExecute('outdent');
			break;
		case 'KE_REMOVE':
			KindSimpleExecute('removeformat');
			break;
		case 'KE_ZOOM':
			KindDisplayMenu(cmd);
			document.getElementById("POPUP_"+cmd).innerHTML=KE_ZOOM_value;
			break;
		case 'KE_ZOOM_END':
			KindEditorForm.focus();
			KE_EDITFORM_DOCUMENT.body.style.zoom = value;
			KindDisableMenu();
			break;
		case 'KE_TITLE':
			KindDisplayMenu(cmd);
			document.getElementById("POPUP_"+cmd).innerHTML=KE_TITLE_value;
			break;
		case 'KE_TITLE_END':
			KindEditorForm.focus();
			value = '<' + value + '>';
			KindSelect();
			KindExecuteValue('FormatBlock', value);
			KindDisableMenu();
			break;
		case 'KE_FONTNAME':
			KindDisplayMenu(cmd);
			document.getElementById("POPUP_"+cmd).innerHTML=KE_FONTNAME_value;
			break;
		case 'KE_FONTNAME_END':
			KindEditorForm.focus();
			KindSelect();
			KindExecuteValue('fontname', value);
			KindDisableMenu();
			break;
		case 'KE_FONTSIZE':
			KindDisplayMenu(cmd);
			document.getElementById("POPUP_"+cmd).innerHTML=KE_FONTSIZE_value;
			break;
		case 'KE_FONTSIZE_END':
			KindEditorForm.focus();
			value = value.substr(0, 1);
			KindSelect();
			KindExecuteValue('fontsize', value);
			KindDisableMenu();
			break;
		case 'KE_TEXTCOLOR':
			KindDisplayMenu(cmd);
			document.getElementById("POPUP_"+cmd).innerHTML=KE_TEXTCOLOR_value;
			break;
		case 'KE_TEXTCOLOR_END':
			KindEditorForm.focus();
			KindSelect();
			KindExecuteValue('ForeColor', value);
			KindDisableMenu();
			break;
		case 'KE_BGCOLOR':
			KindDisplayMenu(cmd);
			document.getElementById("POPUP_"+cmd).innerHTML=KE_BGCOLOR_value;
			break;
		case 'KE_BGCOLOR_END':
			KindEditorForm.focus();
			if (KE_BROWSER == 'IE') {
				KindSelect();
				KindExecuteValue('BackColor', value);
			} else {
				var startRangeNode = KE_RANGE.startContainer;
				if (startRangeNode.nodeType == 3) {
					var parent = startRangeNode.parentNode;
					var element = document.createElement("font");
					element.style.backgroundColor = value;
					element.appendChild(KE_RANGE.extractContents());
					var startRangeOffset = KE_RANGE.startOffset;
					var newRange = document.createRange();
					var afterNode;
					var textNode = startRangeNode;
					startRangeNode = textNode.parentNode;
					var text = textNode.nodeValue;
					var textBefore = text.substr(0, startRangeOffset);
					var textAfter = text.substr(startRangeOffset);
					var beforeNode = document.createTextNode(textBefore);
					var afterNode = document.createTextNode(textAfter);
					startRangeNode.insertBefore(afterNode, textNode);
					startRangeNode.insertBefore(element, afterNode);
					startRangeNode.insertBefore(beforeNode, element);
					startRangeNode.removeChild(textNode);
					newRange.setEnd(afterNode, 0);
					newRange.setStart(afterNode, 0);
					KE_SELECTION.addRange(newRange);
				}
			}
			KindDisableMenu();
			break;
		case 'KE_ICON':
			KindDisplayMenu(cmd);
			document.getElementById("POPUP_"+cmd).innerHTML=KE_ICON_value();
			break;
		case 'KE_ICON_END':
			KindEditorForm.focus();
			var element = document.createElement("img");
			element.src = value;
			element.border = 0;
			element.alt = "";
			KindSelect();
			KindInsertItem(element);
			KindDisableMenu();
			break;
		case 'KE_IMAGE':
			KindDisplayMenu(cmd);
			KindImageIframe.focus();
			KE_IMAGE_DOCUMENT.getElementById(cmd+'submitButton').focus();
			break;
		case 'KE_FLV':
			KindDisplayMenu(cmd);
			KindImageP8FLVIframe.focus();
			KE_FLV_DOCUMENT.getElementById(cmd+'submitButton').focus();
			break;
		case 'KE_MYFILES':
			KindDisplayMenu(cmd);
			KindImageP8MYFILESIframe.focus();
			KE_MYFILES_DOCUMENT.getElementById(cmd+'submitButton').focus();
			break;
		case 'KE_FLASH':
			KindDisplayMenu(cmd);
			KindFlashIframe.focus();
			KE_FLASH_DOCUMENT.getElementById(cmd+'submitButton').focus();
			break;
		case 'KE_MEDIA':
			KindDisplayMenu(cmd);
			KindMediaIframe.focus();
			KE_MEDIA_DOCUMENT.getElementById(cmd+'submitButton').focus();
			break;
		case 'KE_REAL':
			KindDisplayMenu(cmd);
			KindRealIframe.focus();
			KE_REAL_DOCUMENT.getElementById(cmd+'submitButton').focus();
			break;
		case 'KE_LINK':
			KindDisplayMenu(cmd);
			KindLinkIframe.focus();
			KE_LINK_DOCUMENT.getElementById(cmd+'submitButton').focus();
			break;
		case 'KE_UNLINK':
			KindSimpleExecute('unlink');
			break;
		case 'KE_SPECIALCHAR':
			KindDisplayMenu(cmd);
			document.getElementById("POPUP_"+cmd).innerHTML=KE_SPECIALCHAR_value;
			break;
		case 'KE_SPECIALCHAR_END':
			KindEditorForm.focus();
			KindSelect();
			var element = document.createElement("span");
			element.appendChild(document.createTextNode(value));
			KindInsertItem(element);
			KindDisableMenu();
			break;
		case 'KE_LAYER':
			KindDisplayMenu(cmd);
			document.getElementById("POPUP_"+cmd).innerHTML=KE_LAYER_value;
			break;
		case 'KE_LAYER_END':
			KindEditorForm.focus();
			var element = document.createElement("div");
			element.style.padding = "5px";
			element.style.border = "1px solid #AAAAAA";
			element.style.backgroundColor = value;
			var childElement = document.createElement("div");
			childElement.innerHTML = KE_LANG['INPUT_CONTENT'];
			element.appendChild(childElement);
			KindSelect();
			KindInsertItem(element);
			KindDisableMenu();
			break;
		case 'KE_TABLE':
			KindDisplayMenu(cmd);
			document.getElementById("POPUP_"+cmd).innerHTML=KE_TABLE_value;
			break;
		case 'KE_TABLE_END':
			KindEditorForm.focus();
			var location = value.split(',');
			var element = document.createElement("table");
			element.cellPadding = 0;
			element.cellSpacing = 0;
			element.border = 1;
			element.style.width = "100px";
			element.style.height = "100px";
			for (var i = 0; i < location[0]; i++) {
				var rowElement = element.insertRow(i);
				for (var j = 0; j < location[1]; j++) {
					var cellElement = rowElement.insertCell(j);
					cellElement.innerHTML = "&nbsp;";
				}
			}
			KindSelect();
			KindInsertItem(element);
			KindDisableMenu();
			break;
		case 'KE_HR':
			KindDisplayMenu(cmd);
			document.getElementById("POPUP_"+cmd).innerHTML=KE_HR_value;
			break;
		case 'KE_HR_END':
			KindEditorForm.focus();
			var element = document.createElement("hr");
			element.width = "100%";
			element.color = value;
			element.size = 1;
			KindSelect();
			KindInsertItem(element);
			KindDisableMenu();
			break;
		case 'KE_DATE':
			KindEditorForm.focus();
			KindSelection();
			var date = new Date();
			var year = date.getFullYear().toString(10);
			var month = (date.getMonth() + 1).toString(10);
			month = month.length < 2 ? '0' + month : month;
			var day = date.getDate().toString(10);
			day = day.length < 2 ? '0' + day : day;
			var value = year + '-' + month + '-' + day;
			var element = document.createElement("span");
			element.appendChild(document.createTextNode(value));
			KindInsertItem(element);
			KindDisableMenu();
			break;
		case 'KE_TIME':
			KindEditorForm.focus();
			KindSelection();
			var date = new Date();
			var hour = date.getHours().toString(10);
			hour = hour.length < 2 ? '0' + hour : hour;
			var minute = date.getMinutes().toString(10);
			minute = minute.length < 2 ? '0' + minute : minute;
			var second = date.getSeconds().toString(10);
			second = second.length < 2 ? '0' + second : second;
			var value = hour + ':' + minute + ':' + second;
			var element = document.createElement("span");
			element.appendChild(document.createTextNode(value));
			KindInsertItem(element);
			KindDisableMenu();
			break;
		case 'KE_PREVIEW':
			eval(KE_OBJ_NAME).data();
			var newWin = window.open('', 'kindPreview','width=800,height=600,left=30,top=30,resizable=yes,scrollbars=yes');
			KindWriteFullHtml(newWin.document, document.getElementsByName(eval(KE_OBJ_NAME).hiddenName)[0].value);
			KindDisableMenu();
			break;
		case 'KE_ABOUT':
			KindDisplayMenu(cmd);
			break;
		default: 
			break;
	}
}
function KindDisableToolbar(flag)
{
	if (flag == true) {
		document.getElementById(KE_TOP_TOOLBAR_ICON[0][0]).src = KE_SKIN_PATH + 'design.gif';
		for (i = 0; i < KE_TOOLBAR_ICON.length; i++) {
			var el = document.getElementById(KE_TOOLBAR_ICON[i][0]);
			if (KE_TOOLBAR_ICON[i][0] == 'KE_SOURCE' || KE_TOOLBAR_ICON[i][0] == 'KE_PREVIEW' || KE_TOOLBAR_ICON[i][0] == 'KE_ABOUT') {
				continue;
			}
			el.style.visibility = 'hidden';
		}
	} else {
		document.getElementById(KE_TOP_TOOLBAR_ICON[0][0]).src = KE_SKIN_PATH + 'source.gif';
		for (i = 0; i < KE_TOOLBAR_ICON.length; i++) {
			var el = document.getElementById(KE_TOOLBAR_ICON[i][0]);
			el.style.visibility = 'visible';
			KE_EDITFORM_DOCUMENT.designMode = 'On';
		}
	}
}
function KindCreateIcon(icon)
{
	var str = '<img id="'+ icon[0] +'" src="' + KE_SKIN_PATH + icon[1] + '" alt="' + icon[2] + '" title="' + icon[2] + 
			'" align="absmiddle" style="border:1px solid ' + KE_TOOLBAR_BG_COLOR +';cursor:pointer;height:20px;';
	str += '" onclick="javascript:KindExecute(\''+ icon[0] +'\');" '+
			'onmouseover="javascript:this.style.border=\'1px solid ' + KE_MENU_BORDER_COLOR + '\';" ' +
			'onmouseout="javascript:this.style.border=\'1px solid ' + KE_TOOLBAR_BG_COLOR + '\';" ';
	str += '>';
	
	if (icon[0]=='KE_BOKECC')
	{
		if (bokecc_id!='')
		{
			return "<object width='70' height='22'><param name='wmode' value='transparent' /><param name='allowScriptAccess' value='always' /><param name='movie' value='http://union.bokecc.com/flash/plugin/plugin.swf?userID="+bokecc_id+"&type=php168' /><embed src='http://union.bokecc.com/flash/plugin/plugin.swf?userID="+bokecc_id+"&type=php168' type='application/x-shockwave-flash' width='70' height='22' allowFullscreen='true' allowScriptAccess='always'></embed></object>";
		}else{
			return '';
		}
		
	}
	else{
		return str;
	}
	
}
function KindCreateToolbar()
{
	var htmlData = '<table cellpadding="0" cellspacing="0" border="0" height="26"><tr>';
	if (KE_EDITOR_TYPE == 'full') {
		for (i = 0; i < KE_TOP_TOOLBAR_ICON.length; i++) {
			htmlData += '<td style="padding:2px;">' + KindCreateIcon(KE_TOP_TOOLBAR_ICON[i]) + '</td>';
		}
		htmlData += '</tr></table><table cellpadding="0" cellspacing="0" border="0" height="26"><tr>';
		for (i = 0; i < KE_BOTTOM_TOOLBAR_ICON.length; i++) {
			htmlData += '<td style="padding:2px;">' + KindCreateIcon(KE_BOTTOM_TOOLBAR_ICON[i]) + '</td>';
		}
	} else {
		for (i = 0; i < KE_SIMPLE_TOOLBAR_ICON.length; i++) {
			htmlData += '<td style="padding:2px;">' + KindCreateIcon(KE_SIMPLE_TOOLBAR_ICON[i]) + '</td>';
		}
	}
	htmlData += '</tr></table>';
	return htmlData;
}
function KindWriteFullHtml(documentObj, content)
{
	var editHtmlData = '';
	editHtmlData += '<html>\r\n<head>\r\n<title>KindEditor</title>\r\n';
	editHtmlData += '<link href="'+KE_CSS_PATH+'" rel="stylesheet" type="text/css">\r\n</head>\r\n<body>\r\n';
	editHtmlData += content;
	editHtmlData += '\r\n</body>\r\n</html>\r\n';
	documentObj.open();
	documentObj.write(editHtmlData);
	documentObj.close();
}
function KindEditor(objName) 
{
	this.objName = objName;
	this.hiddenName = objName;
	this.siteDomain;
	this.editorType;
	this.safeMode;
	this.uploadMode;
	this.editorWidth;
	this.editorHeight;
	this.skinPath;
	this.iconPath;
	this.imageAttachPath;
	this.imageUploadCgi;
	this.cssPath;
	this.menuBorderColor;
	this.menuBgColor;
	this.menuTextColor;
	this.menuSelectedColor;
	this.toolbarBorderColor;
	this.toolbarBgColor;
	this.formBorderColor;
	this.formBgColor;
	this.buttonColor;
	this.parentID;
	this.init = function()
	{
		if (this.siteDomain) KE_SITE_DOMAIN = this.siteDomain;
		if (this.editorType) KE_EDITOR_TYPE = this.editorType.toLowerCase();
		if (this.safeMode) KE_SAFE_MODE = this.safeMode;
		if (this.uploadMode) KE_UPLOAD_MODE = this.uploadMode;
		if (this.editorWidth) KE_WIDTH = this.editorWidth;
		if (this.editorHeight) KE_HEIGHT = this.editorHeight;
		if (this.skinPath) KE_SKIN_PATH = this.skinPath;
		if (this.iconPath) KE_ICON_PATH = this.iconPath;
		if (this.imageAttachPath) KE_IMAGE_ATTACH_PATH = this.imageAttachPath;
		if (this.imageUploadCgi) KE_IMAGE_UPLOAD_CGI = this.imageUploadCgi;
		if (this.cssPath) KE_CSS_PATH = this.cssPath;
		if (this.menuBorderColor) KE_MENU_BORDER_COLOR = this.menuBorderColor;
		if (this.menuBgColor) KE_MENU_BG_COLOR = this.menuBgColor;
		if (this.menuTextColor) KE_MENU_TEXT_COLOR = this.menuTextColor;
		if (this.menuSelectedColor) KE_MENU_SELECTED_COLOR = this.menuSelectedColor;
		if (this.toolbarBorderColor) KE_TOOLBAR_BORDER_COLOR = this.toolbarBorderColor;
		if (this.toolbarBgColor) KE_TOOLBAR_BG_COLOR = this.toolbarBgColor;
		if (this.formBorderColor) KE_FORM_BORDER_COLOR = this.formBorderColor;
		if (this.formBgColor) KE_FORM_BG_COLOR = this.formBgColor;
		if (this.buttonColor) KE_BUTTON_COLOR = this.buttonColor;
		KE_OBJ_NAME = this.objName;
		KE_BROWSER = KindGetBrowser();
		KE_TOOLBAR_ICON = Array();
		for (var i = 0; i < KE_TOP_TOOLBAR_ICON.length; i++) {
			KE_TOOLBAR_ICON.push(KE_TOP_TOOLBAR_ICON[i]);
		}
		for (var i = 0; i < KE_BOTTOM_TOOLBAR_ICON.length; i++) {
			KE_TOOLBAR_ICON.push(KE_BOTTOM_TOOLBAR_ICON[i]);
		}
	}
	this.show = function()
	{
		this.init();
		var widthStyle = 'width:' + KE_WIDTH + ';';
		var widthArr = KE_WIDTH.match(/(\d+)([px%]{1,2})/);
		var iframeWidthStyle = 'width:' + (parseInt(widthArr[1]) - 2).toString(10) + widthArr[2] + ';';
		var heightStyle = 'height:' + KE_HEIGHT + ';';
		var heightArr = KE_HEIGHT.match(/(\d+)([px%]{1,2})/);
		var iframeHeightStyle = 'height:' + (parseInt(heightArr[1]) - 3).toString(10) + heightArr[2] + ';';
		if (KE_BROWSER == '') {
			var htmlData = '<div id="KindEditTextarea" style="' + widthStyle + heightStyle + '">' +
			'<textarea name="KindCodeForm" id="KindCodeForm" style="' + widthStyle + heightStyle + 
			'padding:0;margin:0;border:1px solid '+ KE_FORM_BORDER_COLOR + 
			';font-size:12px;line-height:16px;font-family:'+KE_FONT_FAMILY+';background-color:'+ 
			KE_FORM_BG_COLOR +';">' + document.getElementsByName(this.hiddenName)[0].value + '</textarea></div>';
			document.open();
			document.write(htmlData);
			document.close();
			return;
		}
		var htmlData = '<div style="font-family:'+KE_FONT_FAMILY+';">';
		htmlData += '<div style="'+widthStyle+';border:1px solid ' + KE_TOOLBAR_BORDER_COLOR + ';background-color:'+ KE_TOOLBAR_BG_COLOR +'">';
		htmlData += KindCreateToolbar();
		htmlData += '</div><div id="KindEditorIframe" style="' + widthStyle + heightStyle + 
			'border:1px solid '+ KE_FORM_BORDER_COLOR +';border-top:0;">' +
			'<iframe name="KindEditorForm" id="KindEditorForm" frameborder="0" style="' + iframeWidthStyle + iframeHeightStyle + 
			'padding:0;margin:0;border:0;"></iframe></div>';
		if (KE_EDITOR_TYPE == 'full') {
			htmlData += '<div id="KindEditTextarea" style="' + widthStyle + heightStyle + 
				'border:1px solid '+ KE_FORM_BORDER_COLOR +';background-color:'+ 
				KE_FORM_BG_COLOR +';border-top:0;display:none;">' +
				'<textarea name="KindCodeForm" id="KindCodeForm" style="' + iframeWidthStyle + iframeHeightStyle + 
				'padding:0;margin:0;border:0;font-size:12px;line-height:16px;font-family:'+KE_FONT_FAMILY+';background-color:'+ 
				KE_FORM_BG_COLOR +';" onclick="javascirit:parent.KindDisableMenu();"></textarea></div>';
		}
		htmlData += '</div>';
		for (var i = 0; i < KE_POPUP_MENU_TABLE.length; i++) {
			if (KE_POPUP_MENU_TABLE[i] == 'KE_IMAGE') {
				htmlData += '<span id="InsertIframe">';
			}
			htmlData += KindPopupMenu(KE_POPUP_MENU_TABLE[i]);
			if (KE_POPUP_MENU_TABLE[i] == 'KE_REAL') {
				htmlData += '</span>';
			}
		}
		document.open();
		document.write(htmlData);
		document.close();
		if (KE_BROWSER == 'IE') {
			KE_EDITFORM_DOCUMENT = document.frames("KindEditorForm").document;
		} else {
			KE_EDITFORM_DOCUMENT = document.getElementById('KindEditorForm').contentDocument;
		}
		
		KindDrawIframe('KE_IMAGE');
		KindDrawIframe('KE_FLV');
		KindDrawIframe('KE_MYFILES');
		KindDrawIframe('KE_FLASH');
		KindDrawIframe('KE_MEDIA');
		KindDrawIframe('KE_REAL');
		KindDrawIframe('KE_LINK');
		KE_EDITFORM_DOCUMENT.designMode = 'On';
		KindWriteFullHtml(KE_EDITFORM_DOCUMENT, document.getElementsByName(eval(KE_OBJ_NAME).hiddenName)[0].value);
		var el = KE_EDITFORM_DOCUMENT.body;
		if (KE_EDITFORM_DOCUMENT.addEventListener){
			KE_EDITFORM_DOCUMENT.addEventListener('click', KindDisableMenu, false); 
		} else if (el.attachEvent){
			el.attachEvent('onclick', KindDisableMenu);
		}
	}
	this.data = function()
	{
		var htmlResult;
		if (KE_BROWSER == '') {
			htmlResult = document.getElementById("KindCodeForm").value;
		} else {
			if (KE_EDITOR_TYPE == 'full') {
				var length = document.getElementById(KE_TOP_TOOLBAR_ICON[0][0]).src.length - 10;
				var image = document.getElementById(KE_TOP_TOOLBAR_ICON[0][0]).src.substr(length,10);
				if (image == 'source.gif') {
					htmlResult = KE_EDITFORM_DOCUMENT.body.innerHTML;
				} else {
					htmlResult = document.getElementById("KindCodeForm").value;
				}
			} else {
				htmlResult = KE_EDITFORM_DOCUMENT.body.innerHTML;
			}
		}
		KindDisableMenu();
		htmlResult = KindHtmlToXhtml(htmlResult);
		htmlResult = KindClearScriptTag(htmlResult);
		document.getElementsByName(this.hiddenName)[0].value = htmlResult;
		return htmlResult;
	}
	this.code = function()
	{
		var htmlResult;
		if (KE_BROWSER == '') {
			htmlResult = document.getElementById("KindCodeForm").value;
		} else {
			if (KE_EDITOR_TYPE == 'full') {
				var length = document.getElementById(KE_TOP_TOOLBAR_ICON[0][0]).src.length - 10;
				var image = document.getElementById(KE_TOP_TOOLBAR_ICON[0][0]).src.substr(length,10);
				if (image == 'source.gif') {
					htmlResult = KE_EDITFORM_DOCUMENT.body.innerHTML;
				} else {
					htmlResult = document.getElementById("KindCodeForm").value;
				}
			} else {
				htmlResult = KE_EDITFORM_DOCUMENT.body.innerHTML;
			}
		}
		htmlResult = KindHtmlToXhtml(htmlResult);
		htmlResult = KindClearScriptTag(htmlResult);
		parent.document.getElementById(editor.parentID).value = htmlResult;
		return htmlResult;
	}
}



function KE_ICON_value(){
	return '<table cellpadding="0" cellspacing="2" style=" left:1px;font-size:12px;color:#222222;background-color:#EFEFEF;border:solid 0px #AAAAAA; ">  <tr>    <td style="padding:2px;border:0;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ICON_END\', \''+KE_ICON_PATH+'1.gif\');"><img src="'+KE_ICON_PATH+'1.gif" style="border:1px solid #EEEEEE;" onmouseover="javascript:this.style.borderColor=\'#AAAAAA\';" onmouseout="javascript:this.style.borderColor=\'#EEEEEE\';"></td>    <td style="padding:2px;border:0;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ICON_END\', \''+KE_ICON_PATH+'2.gif\');"><img src="'+KE_ICON_PATH+'2.gif" style="border:1px solid #EEEEEE;" onmouseover="javascript:this.style.borderColor=\'#AAAAAA\';" onmouseout="javascript:this.style.borderColor=\'#EEEEEE\';"></td>   <td style="padding:2px;border:0;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ICON_END\', \''+KE_ICON_PATH+'3.gif\');"><img src="'+KE_ICON_PATH+'3.gif" style="border:1px solid #EEEEEE;" onmouseover="javascript:this.style.borderColor=\'#AAAAAA\';" onmouseout="javascript:this.style.borderColor=\'#EEEEEE\';"></td>    <td style="padding:2px;border:0;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ICON_END\', \''+KE_ICON_PATH+'4.gif\');"><img src="'+KE_ICON_PATH+'4.gif" style="border:1px solid #EEEEEE;" onmouseover="javascript:this.style.borderColor=\'#AAAAAA\';" onmouseout="javascript:this.style.borderColor=\'#EEEEEE\';"></td>    <td style="padding:2px;border:0;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ICON_END\', \''+KE_ICON_PATH+'5.gif\');"><img src="'+KE_ICON_PATH+'5.gif" style="border:1px solid #EEEEEE;" onmouseover="javascript:this.style.borderColor=\'#AAAAAA\';" onmouseout="javascript:this.style.borderColor=\'#EEEEEE\';"></td>    <td style="padding:2px;border:0;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ICON_END\', \''+KE_ICON_PATH+'6.gif\');"><img src="'+KE_ICON_PATH+'6.gif" style="border:1px solid #EEEEEE;" onmouseover="javascript:this.style.borderColor=\'#AAAAAA\';" onmouseout="javascript:this.style.borderColor=\'#EEEEEE\';"></td>  <tr>    <td style="padding:2px;border:0;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ICON_END\', \''+KE_ICON_PATH+'7.gif\');"><img src="'+KE_ICON_PATH+'7.gif" style="border:1px solid #EEEEEE;" onmouseover="javascript:this.style.borderColor=\'#AAAAAA\';" onmouseout="javascript:this.style.borderColor=\'#EEEEEE\';"></td>    <td style="padding:2px;border:0;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ICON_END\', \''+KE_ICON_PATH+'8.gif\');"><img src="'+KE_ICON_PATH+'8.gif" style="border:1px solid #EEEEEE;" onmouseover="javascript:this.style.borderColor=\'#AAAAAA\';" onmouseout="javascript:this.style.borderColor=\'#EEEEEE\';"></td>   <td style="padding:2px;border:0;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ICON_END\', \''+KE_ICON_PATH+'9.gif\');"><img src="'+KE_ICON_PATH+'9.gif" style="border:1px solid #EEEEEE;" onmouseover="javascript:this.style.borderColor=\'#AAAAAA\';" onmouseout="javascript:this.style.borderColor=\'#EEEEEE\';"></td>    <td style="padding:2px;border:0;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ICON_END\', \''+KE_ICON_PATH+'10.gif\');"><img src="'+KE_ICON_PATH+'10.gif" style="border:1px solid #EEEEEE;" onmouseover="javascript:this.style.borderColor=\'#AAAAAA\';" onmouseout="javascript:this.style.borderColor=\'#EEEEEE\';"></td>    <td style="padding:2px;border:0;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ICON_END\', \''+KE_ICON_PATH+'11.gif\');"><img src="'+KE_ICON_PATH+'11.gif" style="border:1px solid #EEEEEE;" onmouseover="javascript:this.style.borderColor=\'#AAAAAA\';" onmouseout="javascript:this.style.borderColor=\'#EEEEEE\';"></td>    <td style="padding:2px;border:0;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ICON_END\', \''+KE_ICON_PATH+'12.gif\');"><img src="'+KE_ICON_PATH+'12.gif" style="border:1px solid #EEEEEE;" onmouseover="javascript:this.style.borderColor=\'#AAAAAA\';" onmouseout="javascript:this.style.borderColor=\'#EEEEEE\';"></td>  <tr>    <td style="padding:2px;border:0;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ICON_END\', \''+KE_ICON_PATH+'13.gif\');"><img src="'+KE_ICON_PATH+'13.gif" style="border:1px solid #EEEEEE;" onmouseover="javascript:this.style.borderColor=\'#AAAAAA\';" onmouseout="javascript:this.style.borderColor=\'#EEEEEE\';"></td>   <td style="padding:2px;border:0;cursor:pointer;" onclick="javascript:KindExecute(\'KE_ICON_END\', \''+KE_ICON_PATH+'14.gif\');"><img src="'+KE_ICON_PATH+'14.gif" style="border:1px solid #EEEEEE;" onmouseover="javascript:this.style.borderColor=\'#AAAAAA\';" onmouseout="javascript:this.style.borderColor=\'#EEEEEE\';"></td>    <td style="padding:2px;border:0;cursor:pointer;" onclick="javascript:">&nbsp;</td>    <td style="padding:2px;border:0;cursor:pointer;" onclick="javascript:;">&nbsp;</td>    <td style="padding:2px;border:0;cursor:pointer;" onclick="javascript:;">&nbsp;</td>    <td style="padding:2px;border:0;cursor:pointer;" onclick="javascript:;">&nbsp;</td></table>';
}



function set_ccflv(url)
{
	KindEditorForm.focus();
	KindSelection();

	KindSelect();
	var element = document.createElement("div");
	
	str=" <CENTER><embed type='application/x-shockwave-flash' src='"+url+"' width='400' height='300'></embed></CENTER><br>";
	
	element.innerHTML = str;
	
	KindInsertItem(element);
	KindDisableMenu();
	KindReloadIframe();
	alert("�ϴ��ɹ�,��ע��,�������ϲ���,Ҫ�ȴ���˺���ܲ���.");
}
