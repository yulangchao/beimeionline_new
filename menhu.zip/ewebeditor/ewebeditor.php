<?php
error_reporting(0);
header("location:../do/kindeditor.php?id=$_GET[id]&style=$_GET[style]&etype=$_GET[etype]");exit;
?>