﻿var KE={
	show:function(){
		if(confirm('当前页面使用了kindeditor编辑器,请先下载kindeditor编辑器!')){
			window.location.href='http://down.qibosoft.com/down.php?v=kindeditor';
		}
	}
};