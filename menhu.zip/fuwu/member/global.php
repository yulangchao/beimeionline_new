<?php
define('Memberpath',dirname(__FILE__).'/');

require(Memberpath."../global.php");

/**
*ǰ̨�Ƿ񿪷�
**/
if($webdb[module_close])
{
	$webdb[Info_closeWhy]=str_replace("\r\n","<br>",$webdb[Info_closeWhy]);
	showerr("��ϵͳ��ʱ�ر�:$webdb[Info_closeWhy]");
}

if(!$lfjid){
	showerr("�㻹û��¼");
}

if(count($_POST)<1&&!$nojump&&!strstr($webdb[_www_url],preg_replace("/http:\/\/([^\/]+)\/(.*)/is","http://\\1",$WEBURL))){
	//�������ö����������ʻ�Ա����

	$url = strstr($WEBURL,'/'.basename(dirname(dirname(__FILE__))).'/member/');
	if(ereg('\/$',$url)){
		$url.="?nojump=1";
	}elseif(ereg('\.php$',$url)){
		$url.="?nojump=1";
	}else{
		$url.="&nojump=1";
	}
	echo "<META HTTP-EQUIV=REFRESH CONTENT='0;URL=$webdb[_www_url]".$url."'>";
	exit;
}
?>