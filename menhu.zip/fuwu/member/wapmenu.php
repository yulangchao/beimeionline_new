<?php

return array(
	'�Ǽ��̼���Ϣ'=>array('power'=>'1','link'=>'wappost.php?job=set'),
	'�ͻ���ԤԼ'=>array('power'=>'1','link'=>'wapjoinlist.php?job=guestlist'),
	'�ҵ�ԤԼ'=>array('power'=>'1','link'=>'wapjoinlist.php?job=mylist'),
	'�ղؼ�'=>array('power'=>'1','link'=>'wapcollection.php'),
);

?>