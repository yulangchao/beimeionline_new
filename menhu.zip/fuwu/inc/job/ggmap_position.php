<?php
if(!$webdb['gg_map_api']){
	require_once(ROOT_PATH."hy/data{$GLOBALS[webdb][web_dir]}/config.php");
}
require_once(ROOT_PATH."hy/inc/job/".basename(__FILE__));
?>