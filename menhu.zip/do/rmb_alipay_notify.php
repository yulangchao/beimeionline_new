<?php
require("global.php");


require("rmb.inc.php");


require(ROOT_PATH.'inc/wapolpay/alipay/notify_url.php');
?>