<?php
require("global.php");

require("rmb.inc.php");


require(ROOT_PATH.'inc/wapolpay/alipay/return_url.php');


?>