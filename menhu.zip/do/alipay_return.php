<?php
require("global.php");

require("olpay.inc.php");


require(ROOT_PATH.'inc/wapolpay/alipay/return_url.php');


?>