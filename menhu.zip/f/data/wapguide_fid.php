<?php
@include(str_replace(substr(ROOT_PATH,0,-1),ROOT_PATH.PC_PATH,__FILE__));
?>