<?php
require_once(ROOT_PATH."hy/inc/job/".basename(__FILE__));
?>