<?php
$webdb['module_id']='21';
$webdb['module_pre']='form_';
$webdb['Info_webOpen']='1';
$webdb['Info_webname']='���ܱ���';
